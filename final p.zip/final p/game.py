#!/usr/bin/env python3
import math
import random
import pygame
import queue

BG_COLOR = (10, 12, 18)
WALL_COLOR = (0, 180, 220)
PLAYER_COLOR = (255, 220, 0)
GOAL_COLOR = (0, 255, 120)
TEXT_CYAN = (0, 220, 255)
TEXT_DIM = (0, 140, 170)

MAZE_COLS = 9
MAZE_ROWS = 6
CELL_SIZE = 60
OFFSET_X = (800 - (MAZE_COLS * CELL_SIZE)) // 2
OFFSET_Y = 65

class Maze:
    def __init__(self, cols=MAZE_COLS, rows=MAZE_ROWS):
        self.cols = cols
        self.rows = rows
        self.grid = [[[True, True, True, True] for _ in range(cols)] for _ in range(rows)]
        self.start_pos = (0, 0)
        self.goal_pos = (rows - 1, cols - 1)
        self.generate_random_maze()

    def generate_random_maze(self):
        visited = [[False for _ in range(self.cols)] for _ in range(self.rows)]
        stack = []

        start_r = random.randint(0, self.rows - 1)
        start_c = random.randint(0, self.cols - 1)
        visited[start_r][start_c] = True
        stack.append((start_r, start_c))

        while stack:
            r, c = stack[-1]
            neighbors = []
            directions = [(-1, 0, 0, 2), (0, 1, 1, 3), (1, 0, 2, 0), (0, -1, 3, 1)]
            random.shuffle(directions)

            for dr, dc, wall_out, wall_in in directions:
                nr, nc = r + dr, c + dc
                if 0 <= nr < self.rows and 0 <= nc < self.cols and not visited[nr][nc]:
                    neighbors.append((nr, nc, wall_out, wall_in))

            if neighbors:
                nr, nc, wall_out, wall_in = random.choice(neighbors)
                self.grid[r][c][wall_out] = False
                self.grid[nr][nc][wall_in] = False
                visited[nr][nc] = True
                stack.append((nr, nc))
            else:
                stack.pop()

        corners = [
            ((0, 0), (self.rows - 1, self.cols - 1)),
            ((0, self.cols - 1), (self.rows - 1, 0)),
            ((self.rows - 1, 0), (0, self.cols - 1)),
            ((self.rows - 1, self.cols - 1), (0, 0)),
        ]
        self.start_pos, self.goal_pos = random.choice(corners)

    def move_one_step(self, r, c, direction):
        if direction == 'up':
            if r > 0 and not self.grid[r][c][0]:
                return r - 1, c
        elif direction == 'right':
            if c < self.cols - 1 and not self.grid[r][c][1]:
                return r, c + 1
        elif direction == 'down':
            if r < self.rows - 1 and not self.grid[r][c][2]:
                return r + 1, c
        elif direction == 'left':
            if c > 0 and not self.grid[r][c][3]:
                return r, c - 1
        return r, c

    def draw(self, surface):
        for r in range(self.rows):
            for c in range(self.cols):
                x = OFFSET_X + c * CELL_SIZE
                y = OFFSET_Y + r * CELL_SIZE

                if self.grid[r][c][0]:
                    pygame.draw.line(surface, WALL_COLOR, (x, y), (x + CELL_SIZE, y), 4)
                if self.grid[r][c][1]:
                    pygame.draw.line(surface, WALL_COLOR, (x + CELL_SIZE, y), (x + CELL_SIZE, y + CELL_SIZE), 4)
                if self.grid[r][c][2]:
                    pygame.draw.line(surface, WALL_COLOR, (x, y + CELL_SIZE), (x + CELL_SIZE, y + CELL_SIZE), 4)
                if self.grid[r][c][3]:
                    pygame.draw.line(surface, WALL_COLOR, (x, y), (x, y + CELL_SIZE), 4)

def run_maze_game(screen, clock, stop_event=None, action_queue=None):
    w, h = screen.get_size()
    render_surf = pygame.Surface((800, 480))

    maze = Maze()
    player_r, player_c = maze.start_pos
    goal_r, goal_c = maze.goal_pos
    score = 0
    font = pygame.font.Font(None, 28)
    pulse_timer = 0.0

    def start_new_level():
        nonlocal maze, player_r, player_c, goal_r, goal_c, score
        maze = Maze()
        player_r, player_c = maze.start_pos
        goal_r, goal_c = maze.goal_pos
        score += 1

    running = True
    while running:
        if stop_event and stop_event.is_set():
            break

        if action_queue:
            while not action_queue.empty():
                try:
                    action = action_queue.get_nowait()
                    if action in ['up', 'down', 'left', 'right']:
                        player_r, player_c = maze.move_one_step(player_r, player_c, action)
                    elif action == 'restart':
                        start_new_level()
                    elif action == 'exit':
                        return 'exit_to_main'
                except queue.Empty:
                    break

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            elif event.type == pygame.KEYDOWN:
                if event.key in [pygame.K_UP, pygame.K_w]:
                    player_r, player_c = maze.move_one_step(player_r, player_c, 'up')
                elif event.key in [pygame.K_DOWN, pygame.K_s]:
                    player_r, player_c = maze.move_one_step(player_r, player_c, 'down')
                elif event.key in [pygame.K_LEFT, pygame.K_a]:
                    player_r, player_c = maze.move_one_step(player_r, player_c, 'left')
                elif event.key in [pygame.K_RIGHT, pygame.K_d]:
                    player_r, player_c = maze.move_one_step(player_r, player_c, 'right')
                elif event.key == pygame.K_r:
                    start_new_level()
                elif event.key == pygame.K_ESCAPE:
                    return "exit_to_main"

        if (player_r, player_c) == (goal_r, goal_c):
            start_new_level()

        render_surf.fill(BG_COLOR)
        maze.draw(render_surf)

        pulse_timer += 0.08
        goal_glow_size = int(CELL_SIZE * 0.65 + math.sin(pulse_timer) * 5)
        gx = OFFSET_X + goal_c * CELL_SIZE + CELL_SIZE // 2
        gy = OFFSET_Y + goal_r * CELL_SIZE + CELL_SIZE // 2
        pygame.draw.circle(render_surf, GOAL_COLOR, (gx, gy), max(4, goal_glow_size // 2))

        px = OFFSET_X + player_c * CELL_SIZE + CELL_SIZE // 2
        py = OFFSET_Y + player_r * CELL_SIZE + CELL_SIZE // 2
        pygame.draw.circle(render_surf, PLAYER_COLOR, (px, py), int(CELL_SIZE * 0.30))
        pygame.draw.circle(render_surf, (255, 255, 255), (px, py), int(CELL_SIZE * 0.14))

        header_surf = font.render(f"MAZE LEVEL: {score + 1}", True, TEXT_CYAN)
        render_surf.blit(header_surf, (OFFSET_X, 22))

        hint_surf = font.render("'STOP GAME' to Exit", True, TEXT_DIM)
        render_surf.blit(hint_surf, (800 - hint_surf.get_width() - OFFSET_X, 22))

        if (w, h) != (800, 480):
            scaled_surf = pygame.transform.scale(render_surf, (w, h))
            screen.blit(scaled_surf, (0, 0))
        else:
            screen.blit(render_surf, (0, 0))

        pygame.display.flip()
        clock.tick(60)

    return "exit_to_main"