#!/usr/bin/env python3
import os
import threading
import cv2
import numpy as np
import logging
import config

class FaceIdentifier:
    def __init__(self, embeddings_dir=config.EMBEDDINGS_DIR, models_dir=config.MODELS_DIR):
        self.embeddings_dir = embeddings_dir
        self.models_dir = models_dir

        self.detector_path = os.path.join(self.models_dir, "face_detection_yunet_2023mar.onnx")
        self.recognizer_path = os.path.join(self.models_dir, "face_recognition_sface_2021dec.onnx")

        self.detector = None
        self.recognizer = None
        self.net_lock = threading.Lock()

        self.known_face_features = []
        self.known_face_names = []
        self.scan_line_y = 0

        self._init_models()
        self.load_known_faces()

    def _init_models(self):
        if not os.path.isfile(self.detector_path) or not os.path.isfile(self.recognizer_path):
            logging.error(f"Face model files missing in {self.models_dir}")
            return

        try:
            self.detector = cv2.FaceDetectorYN.create(
                self.detector_path, "", (320, 320), 0.6, 0.3, 5000
            )
            self.recognizer = cv2.FaceRecognizerSF.create(
                self.recognizer_path, ""
            )
            logging.info("YuNet and SFace models loaded.")
        except Exception as e:
            logging.error(f"Failed to load models: {e}")

    def load_known_faces(self):
        self.known_face_features.clear()
        self.known_face_names.clear()
        os.makedirs(self.embeddings_dir, exist_ok=True)

        for filename in os.listdir(self.embeddings_dir):
            if filename.endswith(".npy"):
                name = os.path.splitext(filename)[0].replace("_", " ").title()
                feat = np.load(os.path.join(self.embeddings_dir, filename))
                self.known_face_features.append(feat)
                self.known_face_names.append(name)
                logging.info(f"Loaded embedding for: {name}")

    def extract_face(self, bgr_frame):
        if self.detector is None or self.recognizer is None or bgr_frame is None:
            return None, None, None

        h, w, _ = bgr_frame.shape
        with self.net_lock:
            self.detector.setInputSize((w, h))
            _, faces = self.detector.detect(bgr_frame)

        if faces is None or len(faces) == 0:
            return None, None, None

        aligned_face = self.recognizer.alignCrop(bgr_frame, faces[0])
        feature = self.recognizer.feature(aligned_face)
        return faces[0], aligned_face, feature

    def register_face_from_frame(self, bgr_frame, name):
        _, _, feature = self.extract_face(bgr_frame)
        if feature is None:
            return "no_face"

        clean_name = name.strip().title()
        os.makedirs(self.embeddings_dir, exist_ok=True)

        filepath = os.path.join(self.embeddings_dir, f"{clean_name}.npy")
        np.save(filepath, feature)

        if clean_name in self.known_face_names:
            idx = self.known_face_names.index(clean_name)
            self.known_face_features[idx] = feature
        else:
            self.known_face_features.append(feature)
            self.known_face_names.append(clean_name)

        logging.info(f"Saved memory embedding for: {clean_name}")
        return "success"

    def identify_person(self, bgr_frame):
        _, _, feat = self.extract_face(bgr_frame)
        if feat is None:
            return "no_face"

        if not self.known_face_features:
            return "unknown"

        best_score = 0.0
        best_name = "unknown"

        for known_feat, name in zip(self.known_face_features, self.known_face_names):
            score = self.recognizer.match(feat, known_feat, cv2.FaceRecognizerSF_FR_COSINE)
            if score > best_score:
                best_score = score
                if score >= 0.363:
                    best_name = name

        return best_name

    def render_corner_scanner_bgr(self, frame, target_size=(220, 165)):
        if frame is None or self.detector is None:
            return None

        pip = cv2.resize(frame, target_size)
        ph, pw, _ = pip.shape

        faces = None
        with self.net_lock:
            self.detector.setInputSize((pw, ph))
            _, faces = self.detector.detect(pip)

        cv2.rectangle(pip, (0, 0), (pw - 1, ph - 1), (255, 255, 0), 2)
        cv2.putText(pip, "FACE SCAN", (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 0), 1)

        self.scan_line_y = (self.scan_line_y + 6) % max(1, ph)
        cv2.line(pip, (0, self.scan_line_y), (pw, self.scan_line_y), (0, 255, 0), 2)

        if faces is not None and len(faces) > 0:
            fx, fy, fw, fh = map(int, faces[0][:4])
            cv2.rectangle(pip, (fx, fy), (fx + fw, fy + fh), (0, 255, 0), 2)

        return pip