
#!/usr/bin/env python3
from __future__ import annotations

import logging
import random
import threading
import time
from enum import Enum
from typing import Callable, List, Optional, Tuple

import serial

import config

logger = logging.getLogger("RubyMovement")


class MovementCommand(Enum):
    """Supported motor control commands accepted by the ESP32 firmware."""
    FORWARD = "forward"
    BACKWARD = "backward"
    LEFT = "left"
    RIGHT = "right"
    STOP = "stop"

    @classmethod
    def parse(cls, value: str) -> Optional[MovementCommand]:
        try:
            return cls(value.strip().lower())
        except ValueError:
            return None


class MovementController:
    """Coordinates low-level serial actuation, obstacle sensing, and motion behaviors."""

    DEFAULT_TIMEOUT: float = 0.2
    RECONNECT_DELAY: float = 2.0
    OBSTACLE_DEBOUNCE_SEC: float = 2.5

    def __init__(
        self,
        serial_port: str = getattr(config, "SERIAL_PORT", "/dev/ttyUSB0"),
        baud_rate: int = getattr(config, "BAUD_RATE", 115200),
        speak_fn: Optional[Callable[[str], None]] = None,
    ) -> None:
        self.port = serial_port
        self.baud = baud_rate
        self.speak_fn = speak_fn or (lambda msg: None)

        # Serial IO Synchronization
        self._serial: Optional[serial.Serial] = None
        self._write_lock = threading.Lock()

        # Global Lifecycle Controls
        self._app_stop = threading.Event()
        self.obstacle_flag = threading.Event()

        # Routine Worker State
        self._dance_stop = threading.Event()
        self._dance_thread: Optional[threading.Thread] = None

        self._roam_stop = threading.Event()
        self._roam_thread: Optional[threading.Thread] = None

        self.last_direction: MovementCommand = MovementCommand.FORWARD

        self.connect()

        # Telemetry Ingestion Worker
        self._reader_thread = threading.Thread(
            target=self._serial_reader_worker,
            name="Serial-Telemetry-Reader",
            daemon=True,
        )
        self._reader_thread.start()

    # ==========================================================================
    # Serial Interface Management
    # ==========================================================================

    def connect(self) -> bool:
        """Initializes or resets the serial connection to the motor controller."""
        with self._write_lock:
            if self._serial and self._serial.is_open:
                try:
                    self._serial.close()
                except serial.SerialException:
                    pass

            try:
                self._serial = serial.Serial(
                    port=self.port,
                    baudrate=self.baud,
                    timeout=self.DEFAULT_TIMEOUT,
                    write_timeout=1.0,
                )
                # Allow ESP32 auto-reset line to stabilize
                time.sleep(1.5)
                self._serial.reset_input_buffer()
                self._serial.reset_output_buffer()
                logger.info("Serial link established with ESP32 on %s @ %d baud.", self.port, self.baud)
                return True
            except serial.SerialException as error:
                logger.warning("Failed to establish serial connection on %s: %s", self.port, error)
                self._serial = None
                return False

    def send_command(self, cmd: MovementCommand | str) -> bool:
        """Dispatches an atomic line command to the ESP32 driver."""
        command = cmd if isinstance(cmd, MovementCommand) else MovementCommand.parse(cmd)
        if command is None:
            logger.warning("Rejected unsupported movement directive: %s", cmd)
            return False

        payload = f"{command.value}\n".encode("ascii")

        with self._write_lock:
            if self._serial is None or not self._serial.is_open:
                # Attempt lazy reconnect
                if not self._reconnect_unsafe():
                    return False

            try:
                self._serial.write(payload)
                self._serial.flush()
                logger.debug("Dispatched to ESP32: %s", command.value)
                return True
            except (serial.SerialException, OSError) as err:
                logger.error("Serial write failed on command '%s': %s", command.value, err)
                try:
                    if self._serial:
                        self._serial.close()
                except Exception:
                    pass
                self._serial = None
                return False

    def _reconnect_unsafe(self) -> bool:
        """Attempts reconnect without acquiring lock (internal use only)."""
        try:
            self._serial = serial.Serial(
                self.port,
                self.baud,
                timeout=self.DEFAULT_TIMEOUT,
                write_timeout=1.0,
            )
            time.sleep(1.0)
            self._serial.reset_input_buffer()
            self._serial.reset_output_buffer()
            return True
        except serial.SerialException:
            self._serial = None
            return False

    # ==========================================================================
    # Background Telemetry & Sensor Parsing
    # ==========================================================================

    def _serial_reader_worker(self) -> None:
        """Monitors incoming telemetry lines for collision and obstacle notifications."""
        last_alert_time = 0.0

        while not self._app_stop.is_set():
            active_serial = self._serial
            if active_serial is None or not active_serial.is_open:
                time.sleep(self.RECONNECT_DELAY)
                continue

            try:
                # Readline without blocking the write lock
                raw_bytes = active_serial.readline()
                if not raw_bytes:
                    continue

                line = raw_bytes.decode("utf-8", errors="replace").strip().lower()
                if not line:
                    continue

                now = time.time()
                if any(keyword in line for keyword in ("obstacle", "object", "blocked")):
                    self.obstacle_flag.set()
                    if not self.is_busy() and (now - last_alert_time > self.OBSTACLE_DEBOUNCE_SEC):
                        last_alert_time = now
                        self.stop()
                        threading.Thread(
                            target=self.speak_fn,
                            args=("Object detected.",),
                            daemon=True,
                        ).start()

            except (serial.SerialException, OSError):
                time.sleep(1.0)

    # ==========================================================================
    # State Inspection & Concurrency Utilities
    # ==========================================================================

    def is_dancing(self) -> bool:
        return self._dance_thread is not None and self._dance_thread.is_alive()

    def is_roaming(self) -> bool:
        return self._roam_thread is not None and self._roam_thread.is_alive()

    def is_busy(self) -> bool:
        return self.is_dancing() or self.is_roaming()

    def stop_all_workers(self) -> None:
        """Terminates any active autonomous routine threads."""
        self._dance_stop.set()
        self._roam_stop.set()

        if self._dance_thread and self._dance_thread.is_alive():
            self._dance_thread.join(timeout=0.3)
        if self._roam_thread and self._roam_thread.is_alive():
            self._roam_thread.join(timeout=0.3)

    # ==========================================================================
    # Autonomous Behaviors
    # ==========================================================================

    def dance(self) -> bool:
        """Cancels previous behaviors and executes a timed dance choreography."""
        self.stop_all_workers()
        self._dance_stop.clear()
        self._dance_thread = threading.Thread(
            target=self._dance_worker,
            name="Movement-Dance-Worker",
            daemon=True,
        )
        self._dance_thread.start()
        return True

    def _dance_worker(self) -> None:
        choreography: List[Tuple[MovementCommand, float]] = [
            (MovementCommand.LEFT, 0.6),
            (MovementCommand.RIGHT, 1.2),
            (MovementCommand.LEFT, 0.6),
            (MovementCommand.STOP, 0.2),
            (MovementCommand.FORWARD, 0.4),
            (MovementCommand.BACKWARD, 0.4),
            (MovementCommand.RIGHT, 1.5),
            (MovementCommand.LEFT, 1.5),
            (MovementCommand.FORWARD, 0.3),
            (MovementCommand.BACKWARD, 0.3),
            (MovementCommand.STOP, 0.3),
        ]

        for _ in range(3):
            for cmd, duration in choreography:
                if self._dance_stop.is_set() or self._app_stop.is_set():
                    self.send_command(MovementCommand.STOP)
                    return

                self.send_command(cmd)

                # Interruptible sleep using Event.wait()
                if self._dance_stop.wait(timeout=duration) or self._app_stop.is_set():
                    self.send_command(MovementCommand.STOP)
                    return

        self.send_command(MovementCommand.STOP)

    def stop_dance(self) -> bool:
        self._dance_stop.set()
        if self._dance_thread and self._dance_thread.is_alive():
            self._dance_thread.join(timeout=0.3)
        return self.send_command(MovementCommand.STOP)

    def start_roam(self) -> bool:
        """Starts autonomous wandering with reactive obstacle avoidance."""
        self.stop_all_workers()
        self._roam_stop.clear()
        self.obstacle_flag.clear()
        self._roam_thread = threading.Thread(
            target=self._roam_worker,
            name="Movement-Roam-Worker",
            daemon=True,
        )
        self._roam_thread.start()
        return True

    def _roam_worker(self) -> None:
        self.send_command(MovementCommand.FORWARD)

        while not self._roam_stop.is_set() and not self._app_stop.is_set():
            if self.obstacle_flag.is_set():
                self.obstacle_flag.clear()

                # Back away from obstruction
                self.send_command(MovementCommand.BACKWARD)
                if self._roam_stop.wait(timeout=0.6) or self._app_stop.is_set():
                    break

                # Random pivot turn
                turn_dir = random.choice([MovementCommand.LEFT, MovementCommand.RIGHT])
                self.send_command(turn_dir)
                if self._roam_stop.wait(timeout=random.uniform(0.7, 1.2)) or self._app_stop.is_set():
                    break

                # Resume forward roam
                if not self._roam_stop.is_set():
                    self.send_command(MovementCommand.FORWARD)

            # Polling tick
            self._roam_stop.wait(timeout=0.1)

        self.send_command(MovementCommand.STOP)

    def stop_roam(self) -> bool:
        self._roam_stop.set()
        if self._roam_thread and self._roam_thread.is_alive():
            self._roam_thread.join(timeout=0.3)
        return self.send_command(MovementCommand.STOP)

    # ==========================================================================
    # Directional API
    # ==========================================================================

    def move(self, direction: str | MovementCommand) -> bool:
        """Commands the robot to drive in a specific direction."""
        parsed = direction if isinstance(direction, MovementCommand) else MovementCommand.parse(direction)
        if parsed is None:
            return False

        self.stop_all_workers()
        if self.send_command(parsed):
            # Maintain last linear heading for 'continue' functionality
            if parsed in {MovementCommand.FORWARD, MovementCommand.BACKWARD}:
                self.last_direction = parsed
            else:
                self.last_direction = MovementCommand.FORWARD
            return True
        return False

    def continue_previous(self) -> bool:
        """Resumes the most recently commanded linear direction."""
        self.stop_all_workers()
        return self.send_command(self.last_direction)

    def stop(self) -> bool:
        """Halts all movement and active background routines."""
        self.stop_all_workers()
        return self.send_command(MovementCommand.STOP)

    def release(self) -> None:
        """Performs a shutdown by terminating workers and closing serial interfaces."""
        logger.info("Releasing movement controller resources...")
        self._app_stop.set()
        self.stop_all_workers()
        self.send_command(MovementCommand.STOP)

        with self._write_lock:
            if self._serial and self._serial.is_open:
                try:
                    self._serial.close()
                except (serial.SerialException, OSError):
                    pass
                self._serial = None
        logger.info("Movement controller shutdown complete.")

