#!/usr/bin/env python3
import json
import logging
import queue
import threading
import time
import sounddevice as sd
from vosk import Model, KaldiRecognizer


class VoiceListener(threading.Thread):
    def __init__(
        self,
        model_path,
        phrases,
        command_processor,
        is_speaking_event,
        stop_event,
        sample_rate=16000,
        block_seconds=0.1
    ):
        super().__init__(daemon=True)
        self.model_path = model_path
        # Normalize allowed phrases to lowercase for exact lookup
        self.phrases = {p.strip().lower() for p in phrases if p.strip()}
        self.command_processor = command_processor
        self.is_speaking_event = is_speaking_event
        self.stop_event = stop_event
        self.block_seconds = block_seconds
        self.sample_rate = sample_rate
        self.audio_queue = queue.Queue()

        logging.info("Loading Vosk Speech Recognition...")
        self.model = Model(self.model_path)

        # Retain grammar enforcement, but include "[unk]" for arbitrary speech drops
        grammar_list = sorted(list(self.phrases)) + ["[unk]"]
        self.grammar_json = json.dumps(grammar_list)

        self.rec = KaldiRecognizer(self.model, self.sample_rate, self.grammar_json)
        self.rec.SetWords(False)

        self.is_capturing_name = False

    def _determine_supported_sample_rate(self):
        candidate_rates = [self.sample_rate, 16000, 44100, 48000]
        seen = set()
        rates_to_test = [r for r in candidate_rates if not (r in seen or seen.add(r))]

        for rate in rates_to_test:
            try:
                test_stream = sd.RawInputStream(
                    samplerate=rate,
                    blocksize=int(rate * self.block_seconds),
                    dtype='int16',
                    channels=1
                )
                test_stream.close()
                return rate
            except Exception:
                continue

        try:
            device_info = sd.query_devices(kind='input')
            return int(device_info.get('default_samplerate', 16000))
        except Exception:
            return 16000

    def _drain_audio_queue(self):
        while not self.audio_queue.empty():
            try:
                self.audio_queue.get_nowait()
            except queue.Empty:
                break

    def capture_spoken_name(self, timeout=6.0):
        self.is_capturing_name = True
        # Open-ended recognizer without grammar limits for arbitrary name input
        open_rec = KaldiRecognizer(self.model, self.sample_rate)
        start_time = time.time()
        self._drain_audio_queue()

        captured_name = ""
        try:
            while time.time() - start_time < timeout and not self.stop_event.is_set():
                try:
                    data = self.audio_queue.get(timeout=0.1)
                except queue.Empty:
                    continue

                if self.is_speaking_event.is_set():
                    self._drain_audio_queue()
                    continue

                if open_rec.AcceptWaveform(data):
                    res = json.loads(open_rec.Result())
                    text = res.get('text', '').strip()
                    clean = ' '.join([w for w in text.split() if w != '[unk]']).strip()
                    if clean:
                        captured_name = clean
                        break

            if not captured_name:
                final_res = json.loads(open_rec.FinalResult())
                text = final_res.get('text', '').strip()
                captured_name = ' '.join([w for w in text.split() if w != '[unk]']).strip()

        finally:
            self._drain_audio_queue()
            self.rec.Reset()  # Clear leftover buffer state in the main recognizer
            self.is_capturing_name = False

        return captured_name if captured_name else None

    def _audio_callback(self, indata, frames, time_info, status):
        if status:
            logging.debug(f"Audio status flag: {status}")
        self.audio_queue.put(bytes(indata))

    def run(self):
        active_rate = self._determine_supported_sample_rate()
        block_size = int(active_rate * self.block_seconds)

        if active_rate != self.sample_rate:
            logging.info(f"Adjusting sample rate to {active_rate} Hz.")
            self.sample_rate = active_rate
            self.rec = KaldiRecognizer(self.model, self.sample_rate, self.grammar_json)

        try:
            with sd.RawInputStream(
                samplerate=self.sample_rate,
                blocksize=block_size,
                dtype='int16',
                channels=1,
                callback=self._audio_callback
            ):
                logging.info(f"Listening on {self.sample_rate} Hz...")

                while not self.stop_event.is_set():
                    try:
                        data = self.audio_queue.get(timeout=0.1)
                    except queue.Empty:
                        continue

                    # Don't capture speaker playback
                    if self.is_speaking_event.is_set():
                        self._drain_audio_queue()
                        continue

                    # Hand off chunks directly while name capture is active
                    if self.is_capturing_name:
                        time.sleep(0.01)
                        continue

                    if self.rec.AcceptWaveform(data):
                        res = json.loads(self.rec.Result())
                        raw_text = res.get('text', '').strip()

                        # Strip [unk] tokens
                        clean_words = [w for w in raw_text.split() if w != '[unk]']
                        clean_text = ' '.join(clean_words).strip().lower()

                        # Strict validation: Only execute if exact phrase is registered
                        if clean_text and clean_text in self.phrases:
                            logging.info(f"Verified phrase match: '{clean_text}'")
                            self.command_processor.execute(clean_text)
                        elif clean_text:
                            logging.debug(f"Ignored partial/unregistered phrase: '{clean_text}'")

        except Exception as e:
            logging.error(f"VoiceListener runtime exception: {e}")