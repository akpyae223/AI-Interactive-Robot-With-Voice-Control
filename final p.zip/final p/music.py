#!/usr/bin/env python3
import os
import glob
import random
import logging
import pygame
import config

SONG_KEYS = [
    'that should be me',
    'fool',
    'shape of you'
    'You belong with me',
    'Sunflower',
    'twenty one guns',
]

class MusicPlayer:
    def __init__(self, music_dir=config.MUSIC_DIR, speak_fn=None):
        self.music_dir = music_dir
        self.speak = speak_fn if speak_fn else lambda msg: None
        self.current_song = None
        self.is_paused = False
        
        self._init_mixer()

    def _init_mixer(self):
        try:
            if not pygame.mixer.get_init():
                # 44.1kHz, 16-bit stereo, 2048 buffer for stable Pi playback
                pygame.mixer.pre_init(44100, -16, 2, 2048)
                pygame.mixer.init()
            logging.info("Pygame audio mixer initialized successfully.")
        except Exception as e:
            logging.error(f"Pygame mixer initialization error: {e}")

    def _find_audio_file(self, song_name):
        """Finds any matching audio file (.mp3, .wav, .ogg) in the music directory."""
        if not os.path.isdir(self.music_dir):
            return None

        # 1. Search for clean slug name
        clean_name = song_name.lower().replace(' ', '_')
        for ext in ['*.mp3', '*.wav', '*.ogg']:
            matches = glob.glob(os.path.join(self.music_dir, f"*{clean_name}*{ext}"))
            if matches:
                return matches[0]

        # 2. General fuzzy search across all audio files in the folder
        all_files = glob.glob(os.path.join(self.music_dir, "*.*"))
        for f in all_files:
            if any(part in os.path.basename(f).lower() for part in song_name.lower().split()):
                return f

        return None

    def play(self, song_key, announce=True):
        if not pygame.mixer.get_init():
            self._init_mixer()

        file_path = self._find_audio_file(song_key)
        if not file_path or not os.path.isfile(file_path):
            logging.warning(f"Audio file for '{song_key}' not found in {self.music_dir}")
            if announce:
                self.speak("I couldn't find that song in my storage.")
            return False

        try:
            pygame.mixer.music.stop()
            pygame.mixer.music.load(file_path)
            pygame.mixer.music.set_volume(0.8)
            pygame.mixer.music.play()
            
            self.current_song = song_key
            self.is_paused = False
            logging.info(f"Now playing: {file_path}")

            if announce:
                self.speak(f"Playing {song_key.title()} now!")
            return True
        except Exception as e:
            logging.error(f"Error playing '{file_path}': {e}")
            return False

    def play_random(self, announce=True):
        if not pygame.mixer.get_init():
            self._init_mixer()

        # Find all available audio files in folder
        audio_files = []
        for ext in ['*.mp3', '*.wav', '*.ogg']:
            audio_files.extend(glob.glob(os.path.join(self.music_dir, ext)))

        if not audio_files:
            logging.warning(f"No audio files found in {self.music_dir}")
            if announce:
                self.speak("My music folder is empty.")
            return False

        chosen_file = random.choice(audio_files)
        base_title = os.path.splitext(os.path.basename(chosen_file))[0].replace('_', ' ')

        try:
            pygame.mixer.music.stop()
            pygame.mixer.music.load(chosen_file)
            pygame.mixer.music.set_volume(0.8)
            pygame.mixer.music.play()
            
            self.current_song = base_title
            self.is_paused = False
            logging.info(f"Playing random track: {chosen_file}")

            if announce:
                self.speak(f"Playing {base_title.title()} now!")
            return True
        except Exception as e:
            logging.error(f"Failed to play random audio: {e}")
            return False

    def pause(self):
        if pygame.mixer.get_init() and pygame.mixer.music.get_busy() and not self.is_paused:
            pygame.mixer.music.pause()
            self.is_paused = True
            self.speak("Music paused.")
            return True
        return False

    def resume(self):
        if pygame.mixer.get_init() and self.is_paused:
            pygame.mixer.music.unpause()
            self.is_paused = False
            self.speak("Resuming music.")
            return True
        return False

    def next_song(self):
        return self.play_random(announce=True)

    def stop(self):
        if pygame.mixer.get_init():
            pygame.mixer.music.stop()
        self.is_paused = False
        self.current_song = None
        return True

    def is_playing(self):
        return pygame.mixer.get_init() and (pygame.mixer.music.get_busy() or self.is_paused)