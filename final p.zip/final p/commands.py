#!/usr/bin/env python3
import datetime
import random
import re
import threading
import time
import cv2
from calculation import MathEngine
from recognizer import FaceIdentifier

VMES_INFO = (
    "V M E S stands for Vincent Mary School of Engineering, Science and Technology at Assumption University. "
    "It offers international degree programs in Mechatronics and AI, Aeronautics, "
    "Computer Science, Electrical Engineering, and New Energy Automotive Engineering."
)

ABAC_INFO = (
    "Assumption University, commonly known as ABAC, is Thailand's first international university. "
    "Founded in 1969, it delivers all programs in English and is well known for its business, "
    "technology, and engineering faculties across its Hua Mak and Suvarnabhumi campuses."
)

JOKES = [
    "Why did the computer go to the doctor? It caught a virus!",
    "Why was the math book sad? It had too many problems.",
    "Why do robots never get lost? They always follow the algorithm.",
    "What's a robot's favorite snack? Microchips!",
]

FUN_FACTS = [
    "Octopuses have three hearts.",
    "Honey never spoils; edible pots have been found in ancient Egyptian tombs.",
    "Bananas are berries, but strawberries are not.",
    "A day on Venus lasts longer than its entire year.",
]

RANDOM_RESPONSES = {
    'hello': ["Hello! I'm Ruby, what can I help you with?", "Hi! Great to see you."],
    'thank_you': ["You're very welcome!", "Anytime, that's what I'm here for."],
    'how_are_you': ["I'm doing great, thank you!", "All systems operational!"],
    'nice_to_meet_you': ["Nice to meet you too! It's great having you here.", "The pleasure is all mine!"],
    'unrecognized': ["I didn't quite catch that. Could you say it again?", "That's beyond my memory, try asking me something else!"],
}

def get_current_time_str():
    now = datetime.datetime.now()
    hour = int(now.strftime('%I'))
    minute = now.minute
    period = now.strftime('%p')

    if minute == 0:
        return f"The current time is {hour} o'clock {period}."
    elif minute < 10:
        return f"The current time is {hour} oh {minute} {period}."
    else:
        return f"The current time is {hour} {minute} {period}."

def get_current_date_str():
    now = datetime.datetime.now()
    day = now.day
    return f"Today is {now.strftime('%A, %B')} {day}, {now.year}."

COMMANDS = {
    # System Control & Sleep
    'hey ruby': ('start', 'Hello! I am Ruby, what can I help you?', 'system'),
    'hey robot': ('start', 'Hello! I am Ruby, what can I help you?', 'system'),
    'start robot': ('start', 'Hello! I am Ruby, what can I help you?', 'system'),
    'start': ('start', 'Hello! I am Ruby, what can I help you?', 'system'),
    'go to sleep': ('sleep', 'Going to sleep.', 'system'),
    'good night': ('sleep', 'Good night! Rest well.', 'system'),
    'goodbye': ('sleep', 'Bye Bye! Have a nice day.', 'system'),
    'shutdown': ('exit_system', 'Shutting down system. Goodbye!', 'system'),
    'exit': ('exit_system', 'Shutting down system. Goodbye!', 'system'),

    # Movement & Autonomous Roaming
    'move forward': ('forward', '', 'movement'),
    'go forward': ('forward', '', 'movement'),
    'forward': ('forward', '', 'movement'),
    'robot forward': ('forward', '', 'movement'),
    'move backward': ('backward', '', 'movement'),
    'go backward': ('backward', '', 'movement'),
    'backward': ('backward', '', 'movement'),
    'go back': ('backward', '', 'movement'),
    'turn left': ('left', '', 'movement'),
    'robot turn left': ('left', '', 'movement'),
    'left': ('left', '', 'movement'),
    'turn right': ('right', '', 'movement'),
    'robot turn right': ('right', '', 'movement'),
    'right': ('right', '', 'movement'),
    'continue': ('continue_move', '', 'movement'),
    'robot continue': ('continue_move', '', 'movement'),
    'resume': ('continue_move', '', 'movement'),
    'move around': ('start_roam', 'Exploring and moving around now!', 'movement'),
    'start move around': ('start_roam', 'Exploring and moving around now!', 'movement'),
    'explore': ('start_roam', 'Exploring and moving around now!', 'movement'),
    'stop moving around': ('stop', '', 'movement'),
    'stop': ('stop', '', 'movement'),
    'robot stop': ('stop', '', 'movement'),

    # Entertainment & Dance
    'dance': ('dance', '', 'entertainment'),
    'start dance': ('dance', '', 'entertainment'),
    'stop dancing': ('stop_dance', '', 'entertainment'),
    'stop dance': ('stop_dance', '', 'entertainment'),

    # Music Playback
    'play music': ('play_random', '', 'music'),
    'play a song': ('play_random', '', 'music'),
    'pause music': ('pause_song', '', 'music'),
    'pause song': ('pause_song', '', 'music'),
    'pause': ('pause_song', '', 'music'),
    'resume music': ('resume_song', '', 'music'),
    'continue music': ('resume_song', '', 'music'),
    'play music again': ('resume_song', '', 'music'),
    'next music': ('next_song', '', 'music'),
    'next song': ('next_song', '', 'music'),
    'stop music': ('stop_song', 'Music stopped.', 'music'),

    # Music Tracks
    'play that should be me': ('play_track_that_should_be_me', '', 'music'),
    'play fool': ('play_track_fool', '', 'music'),
    'play shape of you': ('play_track_shape_of_you', '', 'music'),
    'play you belong with me': ('play_track_you_belong_with_me', '', 'music'),
    'play sunflower': ('play_track_sunflower', '', 'music'),
    'play twenty one guns': ('play_track_twenty_one_guns', '', 'music'),
    # Knowledge Base & University Info
    'what is vmes': ('info_vmes', VMES_INFO, 'chat'),
    'what is v m e s': ('info_vmes', VMES_INFO, 'chat'),
    'tell me about vmes': ('info_vmes', VMES_INFO, 'chat'),
    'tell me about v m e s': ('info_vmes', VMES_INFO, 'chat'),
    'vmes': ('info_vmes', VMES_INFO, 'chat'),
    'v m e s': ('info_vmes', VMES_INFO, 'chat'),
    'what is abac': ('info_abac', ABAC_INFO, 'chat'),
    'what is a b a c': ('info_abac', ABAC_INFO, 'chat'),
    'tell me about abac': ('info_abac', ABAC_INFO, 'chat'),
    'tell me about a b a c': ('info_abac', ABAC_INFO, 'chat'),
    'abac': ('info_abac', ABAC_INFO, 'chat'),
    'a b a c': ('info_abac', ABAC_INFO, 'chat'),
    'what is assumption university': ('info_abac', ABAC_INFO, 'chat'),
    'tell me about assumption university': ('info_abac', ABAC_INFO, 'chat'),

    # Identity & Chat
    'what is your name': ('talk', 'Hello! My name is Ruby.', 'chat'),
    'who are you': ('talk', "I'm Ruby, an offline AI robot. I can move, solve math, play music, and chat, no internet needed.", 'chat'),
    'what can you do': ('talk', "I can move around, play songs, tell jokes, solve math, play games, or share fun facts!", 'chat'),
    'do you know me': ('identify_user', '', 'chat'),
    'do you no me': ('identify_user', '', 'chat'),
    'do no me': ('identify_user', '', 'chat'),
    'hello': ('dynamic_hello', '', 'chat'),
    'hi': ('dynamic_hello', '', 'chat'),
    'thank you': ('dynamic_thank_you', '', 'chat'),
    'thanks': ('dynamic_thank_you', '', 'chat'),
    'how are you': ('dynamic_how_are_you', '', 'chat'),
    'who am i': ('identify_user', '', 'chat'),
    'who an i': ('identify_user', '', 'chat'),
    'tell me a joke': ('dynamic_joke', '', 'chat'),
    'tell me a fact': ('dynamic_fact', '', 'chat'),
    'what time is it': ('dynamic_time', '', 'chat'),
    'what is today date': ('dynamic_date', '', 'chat'),
    'nice to meet you': ('dynamic_nice_to_meet_you', '', 'chat'),

    # Camera & Mini-Game
    'take a photo': ('show_camera', 'Camera preview on! Pose and say snap or cheese.', 'camera'),
    'take photo': ('show_camera', 'Camera preview on! Pose and say snap or cheese.', 'camera'),
    'snap': ('take_snap', '', 'camera'),
    'cheese': ('take_snap', '', 'camera'),
    'save photo': ('save_photo', '', 'camera'),
    'save': ('save_photo', '', 'camera'),
    'delete photo': ('delete_photo', '', 'camera'),
    'delete': ('delete_photo', '', 'camera'),
    'cancel photo': ('cancel_camera', 'Camera closed.', 'camera'),
    'play game': ('start_maze', 'Starting Maze Game! Say up, down, left, right to navigate.', 'game'),
    'start game': ('start_maze', 'Starting Maze Game! Say up, down, left, right to navigate.', 'game'),
    'play maze': ('start_maze', 'Starting Maze Game! Say up, down, left, right to navigate.', 'game'),
    'maze game': ('start_maze', 'Starting Maze Game! Say up, down, left, right to navigate.', 'game'),
    'maze': ('start_maze', 'Starting Maze Game! Say up, down, left, right to navigate.', 'game'),
    'stop game': ('exit_game', 'Exiting game, welcome back!', 'game'),
    'exit game': ('exit_game', 'Exiting game, welcome back!', 'game'),
    'quit game': ('exit_game', 'Exiting game, welcome back!', 'game'),
}

class CommandProcessor:
    def __init__(self, tts, mover, music_player, camera, game_action_queue, pygame_stop_event):
        self.tts = tts
        self.mover = mover
        self.music_player = music_player
        self.camera = camera
        self.game_action_queue = game_action_queue
        self.pygame_stop_event = pygame_stop_event
        self.listener = None

        self.math_engine = MathEngine()
        self.identifier = FaceIdentifier()
        
        # Start in sleep mode by default
        self.robot_sleeping = True
        self.game_active = False
        self.current_mode = 'idle'
        
        self.awaiting_permission = False
        self.music_started_by_dance = False
        self.scan_until_time = 0.0
        self.camera_opened_time = 0.0

        # Autonomous Roam & Obstacle Avoidance Threading
        self.is_autonomous_roaming = False
        self.roam_thread = None
        self.obstacle_threshold_cm = 25.0  # Detection threshold

    @property
    def face(self):
        return getattr(self.tts, 'face', None)

    @property
    def is_scanner_active(self):
        return (time.time() < self.scan_until_time) or self.awaiting_permission or (self.current_mode == 'scanning')

    def set_listener(self, listener):
        self.listener = listener

    def speak(self, text):
        self.tts.speak(text)

    def set_mode(self, new_mode):
        self.current_mode = new_mode
        if self.face:
            self.face.current_mode = new_mode

    def _get_sensor_distance(self):
        """Attempts to poll ultrasonic/distance sensors from mover or attached interfaces."""
        if hasattr(self.mover, 'get_distance'):
            try:
                return float(self.mover.get_distance())
            except Exception:
                pass
        if hasattr(self.mover, 'distance_sensor'):
            sensor = getattr(self.mover, 'distance_sensor')
            if hasattr(sensor, 'distance'):
                return float(sensor.distance * 100.0)  # Convert m to cm if gpiozero
            if hasattr(sensor, 'get_distance'):
                return float(sensor.get_distance())
        return None

    def _autonomous_roam_worker(self):
        """Monitors obstacles, performs evasive turns, and keeps moving."""
        consecutive_obstacles = 0

        while self.is_autonomous_roaming and not self.robot_sleeping:
            dist = self._get_sensor_distance()

            # Obstacle detected within critical distance
            if dist is not None and 0 < dist < self.obstacle_threshold_cm:
                consecutive_obstacles += 1
                
                # 1. Immediate brake
                self.mover.stop()
                if self.face:
                    self.face.set_mood("SURPRISED", duration=1.0)
                time.sleep(0.15)

                # 2. Back up briefly to create steering clearance
                self.mover.move('backward')
                time.sleep(0.4)
                self.mover.stop()
                time.sleep(0.1)

                # 3. Decide turn direction and turn angle
                # If repeatedly blocked, force a full 180 turnaround
                if consecutive_obstacles >= 3:
                    turn_direction = 'right'
                    turn_time = 1.2
                    consecutive_obstacles = 0
                else:
                    turn_direction = random.choice(['left', 'right'])
                    turn_time = random.uniform(0.6, 0.9)

                self.mover.move(turn_direction)
                time.sleep(turn_time)
                self.mover.stop()
                time.sleep(0.1)

                # 4. Resume forward exploration
                if self.face:
                    self.face.set_mood("NORMAL")
                self.mover.move('forward')

            else:
                consecutive_obstacles = 0
                # Keep moving forward if no active mover-level roam loop is running
                if hasattr(self.mover, 'is_moving') and not self.mover.is_moving:
                    self.mover.move('forward')

            time.sleep(0.08)

    def _start_roam_management(self):
        self.is_autonomous_roaming = True
        # Let mover start its own setup if it has one
        if hasattr(self.mover, 'start_roam'):
            try:
                self.mover.start_roam()
            except Exception:
                self.mover.move('forward')
        else:
            self.mover.move('forward')

        # Launch active supervisor thread
        if self.roam_thread is None or not self.roam_thread.is_alive():
            self.roam_thread = threading.Thread(target=self._autonomous_roam_worker, daemon=True)
            self.roam_thread.start()

    def _stop_roam_management(self):
        self.is_autonomous_roaming = False
        self.mover.stop()

    def reset_to_idle(self):
        self._stop_roam_management()
        self.set_mode('idle')
        self.game_active = False
        self.awaiting_permission = False
        self.music_started_by_dance = False
        if hasattr(self.camera, 'cancel_preview'):
            self.camera.cancel_preview()
        if self.face and not self.robot_sleeping:
            self.face.set_mood("NORMAL")
            self.face.reset_look()

    def _grab_silent_frame(self):
        frame = None
        if self.camera and self.camera.is_available():
            with self.camera.cam_lock:
                if getattr(self.camera, 'latest_bgr_frame', None) is not None:
                    frame = self.camera.latest_bgr_frame.copy()

            if frame is None and hasattr(self.camera, 'cv_cam') and self.camera.cv_cam:
                for _ in range(4):
                    self.camera.cv_cam.grab()
                success, raw_frame = self.camera.cv_cam.read()
                if success and raw_frame is not None:
                    frame = cv2.flip(raw_frame, 1)
        return frame

    def _extract_clean_name(self, raw_text):
        if not raw_text:
            return None

        clean = raw_text.lower().strip()
        prefixes = [
            'my name is', 'i am called', 'i am', 'they call me',
            'call me', 'this is', 'it is', 'its'
        ]
        for prefix in prefixes:
            clean = re.sub(rf'\b{re.escape(prefix)}\b', '', clean).strip()

        filler_words = {'robot', 'ruby', 'please', 'hello', 'hi', 'a', 'the', 'okay', 'yes', 'no', 'yeah'}
        words = [w for w in clean.split() if w not in filler_words and len(w) >= 2]

        if words:
            return words[0].title()
        return None

    def execute(self, text):
        corrected_text = text.lower().strip()

        # Homophone normalization for spoken math calculations
        homophones = [
            (r'\bto\b', 'two'),
            (r'\btoo\b', 'two'),
            (r'\bfor\b', 'four'),
            (r'\bfore\b', 'four'),
            (r'\bate\b', 'eight'),
            (r'\bwon\b', 'one'),
        ]
        for pattern, repl in homophones:
            corrected_text = re.sub(pattern, repl, corrected_text)

        # Homophone normalization for spelled words
        corrected_text = re.sub(r'\bv\s+m\s+e\s+s\b', 'vmes', corrected_text)
        corrected_text = re.sub(r'\ba\s+b\s+a\s+c\b', 'abac', corrected_text)

        print(f'Command: {corrected_text} | Sleeping: [{self.robot_sleeping}] | Mode: [{self.current_mode}]')

        # 1. Wake-up & Exit Intercepts
        wake_triggers = ['hey ruby', 'hey robot', 'start robot', 'start']
        if any(re.search(rf'\b{re.escape(w)}\b', corrected_text) for w in wake_triggers):
            self.robot_sleeping = False
            if self.face:
                self.face.robot_sleeping = False
                self.face.set_mood("HAPPY", duration=3.5)
                self.face.trigger_bounce()
            self.reset_to_idle()
            self.speak("Hello! I am Ruby, what can I help you?")
            return 'start'

        if any(re.search(rf'\b{re.escape(w)}\b', corrected_text) for w in ['shutdown', 'exit']):
            if self.face:
                self.face.set_mood("SAD", duration=3.0)
            self._stop_roam_management()
            self.speak("Shutting down system. Goodbye!")
            self.pygame_stop_event.set()
            return 'exit_system'

        # 2. Block all actions when asleep
        if self.robot_sleeping:
            return 'sleeping'

        # 3. Face Registration Permission Flow
        if self.awaiting_permission:
            positive = ['yes', 'yeah', 'yep', 'sure', 'ok', 'okay', 'please', 'remember', 'save']
            negative = ['no', 'nope', 'never', 'cancel', 'stop', 'exit']

            if any(re.search(rf'\b{w}\b', corrected_text) for w in positive):
                self.awaiting_permission = False
                self.scan_until_time = time.time() + 6.0
                if self.face:
                    self.face.set_mood("HAPPY", duration=4.0)
                    self.face.trigger_bounce()
                self.speak("Great! What is your name?")
                
                spoken_name = self.listener.capture_spoken_name(timeout=5.0) if self.listener else None
                
                if spoken_name:
                    chosen_name = self._extract_clean_name(spoken_name)
                    if chosen_name:
                        frame = self._grab_silent_frame()
                        if frame is not None:
                            status = self.identifier.register_face_from_frame(frame, name=chosen_name)
                            if status == "success":
                                if self.face:
                                    self.face.set_mood("HAPPY", duration=5.0)
                                    self.face.trigger_bounce()
                                self.speak(f"Nice to meet you, {chosen_name}! I have memorized your face.")
                            else:
                                if self.face:
                                    self.face.set_mood("CONFUSED", duration=3.0)
                                self.speak("I had trouble saving your face profile.")
                        else:
                            if self.face:
                                self.face.set_mood("CONFUSED", duration=3.0)
                            self.speak("I could not capture a clear frame of your face.")
                    else:
                        if self.face:
                            self.face.set_mood("CONFUSED", duration=3.0)
                        self.speak("I couldn't hear your name clearly. Let's try again later.")
                else:
                    if self.face:
                        self.face.set_mood("SAD", duration=3.0)
                    self.speak("I didn't hear a name. Registration cancelled.")

                self.scan_until_time = 0.0
                self.reset_to_idle()
                return 'registered_name'

            elif any(re.search(rf'\b{w}\b', corrected_text) for w in negative):
                self.scan_until_time = 0.0
                self.reset_to_idle()
                if self.face:
                    self.face.set_mood("NORMAL", duration=3.0)
                self.speak("No problem, I won't save your face.")
                return 'permission_denied'
            else:
                self.speak("Please say yes if you want me to remember you, or no to cancel.")
                return None

        # 4. Maze Game Controls (Voice Direction Handling)
        if self.current_mode == 'idle' and corrected_text in ['play game', 'start game', 'play maze', 'maze game', 'maze']:
            self.set_mode('game')
            self.game_active = True
            if self.face:
                self.face.set_mood("HAPPY", duration=3.0)
                self.face.trigger_bounce()
            self.speak("Starting Maze Game! Say up, down, left, right to navigate.")
            return 'start_maze'

        if self.current_mode == 'game':
            if any(w in corrected_text for w in ['stop game', 'exit game', 'quit game', 'exit', 'stop']):
                self.game_action_queue.put('exit')
                self.game_active = False
                self.reset_to_idle()
                self.speak("Exiting game, welcome back!")
                return 'exit_game'

            game_directions = {
                'up': 'up', 'go up': 'up', 'move up': 'up',
                'down': 'down', 'go down': 'down', 'move down': 'down',
                'left': 'left', 'go left': 'left', 'move left': 'left', 'turn left': 'left',
                'right': 'right', 'go right': 'right', 'move right': 'right', 'turn right': 'right',
                'restart': 'restart', 'reset': 'restart', 'new game': 'restart'
            }
            for phrase, action in sorted(game_directions.items(), key=lambda x: len(x[0]), reverse=True):
                if re.search(rf'\b{re.escape(phrase)}\b', corrected_text):
                    self.game_action_queue.put(action)
                    return f'game_{action}'
            return None

        # 5. Math Voice Calculations
        if self.current_mode == 'idle':
            math_result = self.math_engine.calculate(corrected_text)
            if math_result:
                if self.face:
                    self.face.set_mood("HAPPY", duration=3.5)
                    self.face.trigger_bounce()
                self.speak(math_result)
                return 'math_calculation'

        # 6. Standard Commands Execution
        for spoken_phrase, (command, response, category) in sorted(COMMANDS.items(), key=lambda item: len(item[0]), reverse=True):
            if re.search(rf'\b{re.escape(spoken_phrase)}\b', corrected_text):

                # Mode Constraints
                if self.current_mode == 'movement' and category != 'movement':
                    if self.face:
                        self.face.set_mood("CONFUSED", duration=2.5)
                    self.speak("I am currently moving. Say 'stop' first to do something else.")
                    return None

                elif self.current_mode == 'music' and category not in ['music', 'entertainment', 'system']:
                    allowed = [
                        'stop', 'stop_song', 'next_song', 'pause_song', 'resume_song',
                        'dance', 'start dance', 'stop_dance'
                    ]
                    if command not in allowed:
                        if self.face:
                            self.face.set_mood("CONFUSED", duration=2.5)
                        self.speak("Music is playing. Stop the music first to do other actions.")
                        return None

                # Camera Mode Gating
                elif self.current_mode == 'camera':
                    is_reviewing = getattr(self.camera, 'is_reviewing', False)

                    if is_reviewing:
                        if command not in ['save_photo', 'delete_photo', 'cancel_camera', 'exit_system']:
                            self.speak("Please say 'save' to keep the photo, or 'delete' to discard it.")
                            return None
                    else:
                        if command in ['stop', 'cancel_camera']:
                            self.camera.cancel_preview()
                            self.reset_to_idle()
                            self.speak("Camera closed.")
                            return 'cancel_camera'
                        elif command not in ['take_snap', 'show_camera', 'exit_system']:
                            self.speak("Say 'snap' to take a photo, or 'stop' to cancel.")
                            return None

                # Camera Controls
                if command == 'show_camera':
                    if self.camera.show_preview():
                        self.set_mode('camera')
                        self.camera_opened_time = time.time()
                        self.speak(response)
                    return command
                if command == 'take_snap' and getattr(self.camera, 'preview_active', False):
                    if time.time() - getattr(self, 'camera_opened_time', 0) < 1.0:
                        return None
                    self.camera.take_photo()
                    return command
                if command == 'save_photo' and getattr(self.camera, 'is_reviewing', False):
                    self.camera.confirm_save()
                    self.reset_to_idle()
                    return command
                if command == 'delete_photo' and getattr(self.camera, 'is_reviewing', False):
                    self.camera.delete_photo()
                    self.reset_to_idle()
                    return command
                if command == 'cancel_camera':
                    self.reset_to_idle()
                    if response: 
                        self.speak(response)
                    return command

                # Movement Controls
                if command in ['forward', 'backward', 'left', 'right']:
                    self._stop_roam_management()
                    self.set_mode('movement')
                    if self.face:
                        self.face.set_mood("NORMAL")
                    self.mover.move(command)
                    return command

                if command == 'continue_move':
                    self.set_mode('movement')
                    if self.face:
                        self.face.set_mood("NORMAL")
                    self.mover.continue_previous()
                    return command

                # Autonomous Roam with Obstacle Avoidance Loop
                if command == 'start_roam':
                    self.set_mode('movement')
                    if self.face:
                        self.face.set_mood("HAPPY")
                        self.face.trigger_bounce()
                    self.speak(response)
                    self._start_roam_management()
                    return command

                if command == 'stop':
                    self.reset_to_idle()
                    if self.current_mode in ['music', 'movement']:
                        self.music_player.stop()
                    self.speak("stopped.")
                    return command

                # Dance Controls
                if command == 'dance':
                    self._stop_roam_management()
                    self.set_mode('music')
                    if self.face:
                        self.face.set_mood("HAPPY")
                        self.face.trigger_bounce()

                    # Check if music is already running
                    music_active = False
                    if hasattr(self.music_player, 'is_playing'):
                        is_playing_attr = getattr(self.music_player, 'is_playing')
                        music_active = is_playing_attr() if callable(is_playing_attr) else bool(is_playing_attr)
                    elif hasattr(self.music_player, 'playing'):
                        playing_attr = getattr(self.music_player, 'playing')
                        music_active = playing_attr() if callable(playing_attr) else bool(playing_attr)

                    # If not playing, trigger random track and mark as started by dance
                    if not music_active:
                        self.music_started_by_dance = True
                        if hasattr(self.music_player, 'play_random'):
                            try:
                                self.music_player.play_random(announce=False)
                            except TypeError:
                                self.music_player.play_random()
                    else:
                        self.music_started_by_dance = False

                    self.mover.dance()
                    return command

                if command == 'stop_dance':
                    self.mover.stop_dance()
                    if self.music_started_by_dance or self.current_mode == 'music':
                        self.music_player.stop()
                    self.reset_to_idle()
                    if self.face:
                        self.face.set_mood("NORMAL")
                    self.speak("Stopped dancing.")
                    return command

                # Music Controls
                if command == 'play_random':
                    self.set_mode('music')
                    self.music_started_by_dance = False
                    if self.face:
                        self.face.set_mood("HAPPY")
                        self.face.trigger_bounce()
                    if hasattr(self.music_player, 'play_random'):
                        try:
                            self.music_player.play_random(announce=True)
                        except TypeError:
                            self.music_player.play_random()
                    return command

                if command.startswith('play_track_'):
                    self.set_mode('music')
                    self.music_started_by_dance = False
                    if self.face:
                        self.face.set_mood("HAPPY")
                        self.face.trigger_bounce()
                    song_key = command.replace('play_track_', '').replace('_', ' ')
                    if hasattr(self.music_player, 'play'):
                        try:
                            self.music_player.play(song_key, announce=True)
                        except TypeError:
                            self.music_player.play(song_key)
                    return command

                if command == 'next_song':
                    self.set_mode('music')
                    if self.face:
                        self.face.set_mood("HAPPY")
                        self.face.trigger_bounce()
                    self.music_player.next_song()
                    return command

                if command == 'pause_song':
                    if self.face:
                        self.face.set_mood("NORMAL")
                    self.music_player.pause()
                    return command

                if command == 'resume_song':
                    # Check if the player is actually paused
                    is_paused = False
                    if hasattr(self.music_player, 'is_paused'):
                        attr = getattr(self.music_player, 'is_paused')
                        is_paused = attr() if callable(attr) else bool(attr)
                    elif hasattr(self.music_player, 'paused'):
                        attr = getattr(self.music_player, 'paused')
                        is_paused = attr() if callable(attr) else bool(attr)

                    if is_paused:
                        self.set_mode('music')
                        if self.face:
                            self.face.set_mood("HAPPY")
                        self.music_player.resume()
                    else:
                        if self.face:
                            self.face.set_mood("CONFUSED", duration=2.5)
                        self.speak("No music is paused right now.")
                    return command

                if command == 'stop_song':
                    self.music_player.stop()
                    self.reset_to_idle()
                    self.speak("Music stopped.")
                    return command

                # Sleep
                if command == 'sleep':
                    self.music_player.stop()
                    self.reset_to_idle()
                    self.robot_sleeping = True
                    if self.face:
                        self.face.robot_sleeping = True
                        self.face.set_mood("SLEEP")
                    self.speak(response)
                    return command

                # Chat, Knowledge Base & Recognition
                if category == 'chat' and self.current_mode == 'idle':
                    if command in ['info_vmes', 'info_abac']:
                        if self.face:
                            self.face.set_mood("NORMAL")
                            self.face.trigger_bounce()
                        self.speak(response)
                    elif command == 'talk': 
                        if self.face:
                            self.face.set_mood("NORMAL")
                        self.speak(response)
                    elif command == 'dynamic_hello': 
                        if self.face:
                            self.face.set_mood("HAPPY", duration=3.5)
                            self.face.trigger_bounce()
                        self.speak(random.choice(RANDOM_RESPONSES['hello']))
                    elif command == 'dynamic_nice_to_meet_you':
                        if self.face:
                            self.face.set_mood("SHY", duration=4.0)
                        self.speak(random.choice(RANDOM_RESPONSES['nice_to_meet_you']))
                    elif command == 'dynamic_thank_you': 
                        if self.face:
                            self.face.set_mood("SHY", duration=3.5)
                        self.speak(random.choice(RANDOM_RESPONSES['thank_you']))
                    elif command == 'dynamic_how_are_you': 
                        if self.face:
                            self.face.set_mood("HAPPY", duration=3.5)
                        self.speak(random.choice(RANDOM_RESPONSES['how_are_you']))
                    elif command == 'dynamic_joke': 
                        if self.face:
                            self.face.set_mood("HAPPY", duration=5.0)
                            self.face.trigger_bounce()
                        self.speak(random.choice(JOKES))
                    elif command == 'dynamic_fact': 
                        if self.face:
                            self.face.set_mood("NORMAL")
                        self.speak(random.choice(FUN_FACTS))
                    elif command == 'dynamic_time': 
                        if self.face:
                            self.face.set_mood("NORMAL")
                        self.speak(get_current_time_str())
                    elif command == 'dynamic_date': 
                        if self.face:
                            self.face.set_mood("NORMAL")
                        self.speak(get_current_date_str())

                    elif command == 'identify_user':
                        self.scan_until_time = time.time() + 3.5
                        if self.face:
                            self.face.set_mood("CONFUSED", duration=2.5)
                        self.speak("Scanning your face...")
                        time.sleep(1.2)

                        frame = self._grab_silent_frame()
                        if frame is not None:
                            result = self.identifier.identify_person(frame)
                            if result == "no_face":
                                self.reset_to_idle()
                                if self.face:
                                    self.face.set_mood("CONFUSED", duration=3.0)
                                self.speak("I don't see anyone in front of me.")
                            elif result == "unknown":
                                self.awaiting_permission = True
                                self.scan_until_time = time.time() + 8.0
                                if self.face:
                                    self.face.set_mood("NORMAL", duration=3.0)
                                self.speak("I don't recognize you yet. Would you like me to remember you?")
                            elif result:
                                self.reset_to_idle()
                                if self.face:
                                    self.face.set_mood("HAPPY", duration=4.5)
                                    self.face.trigger_bounce()
                                self.speak(f"Hello, {result}! Great to see you again.")
                        else:
                            self.reset_to_idle()
                            if self.face:
                                self.face.set_mood("SAD", duration=3.0)
                            self.speak("My camera is currently unavailable.")

                    return command

        return None