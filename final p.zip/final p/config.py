#!/usr/bin/env python3
import os

PROJECT_DIR = os.path.expanduser('~/AIRobot')
MUSIC_DIR = os.path.join(PROJECT_DIR, 'music')
PHOTO_DIR = os.path.join(PROJECT_DIR, 'photos')
CACHE_DIR = os.path.join(PROJECT_DIR, 'kokoro_cache')
EMBEDDINGS_DIR = os.path.join(PROJECT_DIR, 'face_embeddings')
MODELS_DIR = os.path.join(PROJECT_DIR, 'face_models')

# Speech & Voice Recognition Paths
VOSK_MODEL_PATH = os.path.join(PROJECT_DIR, 'vosk-model-small-en-us-0.15')
KOKORO_MODEL_PATH = os.path.join(PROJECT_DIR, 'kokoro', 'kokoro-v0_19.onnx')
KOKORO_VOICES_PATH = os.path.join(PROJECT_DIR, 'kokoro', 'voices.bin')
if not os.path.isfile(KOKORO_VOICES_PATH):
    json_alt = os.path.join(PROJECT_DIR, 'kokoro', 'voices.json')
    if os.path.isfile(json_alt):
        KOKORO_VOICES_PATH = json_alt

# Voice & Assistant Defaults
ASSISTANT_NAME = 'Ruby'
KOKORO_VOICE = 'af'
VOSK_SAMPLE_RATE = 16000
CHANNELS = 1
MIC_BLOCK_SECONDS = 0.03

# Serial Communication & Hardware Timing
SERIAL_PORT = '/dev/ttyUSB0'
BAUD_RATE = 115200
TURN_360_DURATION = 12.5

# Display Resolution
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 480
FULLSCREEN = True