#!/usr/bin/env python3
import os
os.environ['PYTHONWARNINGS'] = 'ignore'

if 'DISPLAY' not in os.environ:
    os.environ['DISPLAY'] = ':0'
import logging
import queue
import threading
import time
import pygame
import cv2
import numpy as np
import config
from commands import CommandProcessor, COMMANDS, JOKES, FUN_FACTS, RANDOM_RESPONSES, VMES_INFO, ABAC_INFO
from listener import VoiceListener
from move import MovementController
from music import MusicPlayer, SONG_KEYS
from photo import CameraController
from tts import TTSEngine
from face_engine import RubyFace
from game import run_maze_game

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S',
)

def precache_phrases(tts):
    phrases = set(item[1] for item in COMMANDS.values() if item[1])
    phrases.update(JOKES + FUN_FACTS)
    phrases.add(VMES_INFO)
    phrases.add(ABAC_INFO)
    for responses in RANDOM_RESPONSES.values():
        phrases.update(responses)
    phrases.update([
        'Three, two, one, smile!',
        'Do you want to save photo or delete it?',
        'Photo saved!',
        'Photo deleted.',
        'Would you like me to remember you?',
        'Great! What is your name?',
        "No problem, I won't save your face.",
        "Please say yes if you want me to remember you, or no to cancel.",
        "Registration cancelled.",
        "I don't see anyone in front of me.",
        "My camera is currently unavailable.",
        "Starting Maze Game! Say up, down, left, right to navigate.",
        'Exiting game, welcome back!',
        'Stopped dancing.',
        'Stopped.',
        'Looking for you now!',
        'Object detected.',
        'There is no previous movement to continue.'
    ])
    for song in SONG_KEYS:
        phrases.add(f"Playing {song.title()} now!")

    tts.precache_phrases(phrases)

def build_vosk_vocabulary():
    math_vocabulary = [
        'what is', 'whats', 'calculate', 'solve', 'how much is', 'equal', 'equals',
        'plus', 'add', 'added', 'to', 'minus', 'subtract', 'times', 'multiplied',
        'by', 'multiply', 'divided', 'divide', 'over', 'power', 'zero', 'one', 'two',
        'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven',
        'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen',
        'nineteen', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty',
        'ninety', 'hundred', 'thousand'
    ]

    permission_words = [
        'yes', 'yeah', 'yep', 'sure', 'ok', 'okay', 'please', 
        'no', 'nope', 'never', 'cancel', 'stop', 'exit'
    ]

    extra_triggers = [
        'ruby', 'hey ruby', 'hi ruby', 'photo', 'snap', 'cheese', 'game', 'play game',
        'maze', 'stop game', 'exit game', 'up', 'down', 'left', 'right', 'continue',
        'next', 'skip', 'dancing', 'dance', 'save', 'delete', 'vmes', 'abac',
        'assumption', 'university', 'find me', 'look for me', 'search for me', '[unk]'
    ]

    vosk_phrases = list(set(
        list(COMMANDS.keys()) + extra_triggers + permission_words + math_vocabulary
    ))
    return sorted(vosk_phrases)

def draw_corner_scanner(screen, camera, identifier):
    """Renders the mini PIP scanning HUD in the top-right corner on demand."""
    frame = None
    if camera and camera.is_available():
        with camera.cam_lock:
            if getattr(camera, 'latest_bgr_frame', None) is not None:
                frame = camera.latest_bgr_frame.copy()

    if frame is not None and identifier is not None:
        pip_bgr = identifier.render_corner_scanner_bgr(frame, target_size=(220, 165))
        if pip_bgr is not None:
            pip_rgb = cv2.cvtColor(pip_bgr, cv2.COLOR_BGR2RGB)
            pip_surface = pygame.surfarray.make_surface(np.rot90(pip_rgb))
            pip_surface = pygame.transform.flip(pip_surface, True, False)

            screen_w, _ = screen.get_size()
            screen.blit(pip_surface, (screen_w - 220 - 20, 20))

def create_window():
    """Initializes and returns the Pygame display surface."""
    pygame.display.init()
    if getattr(config, 'FULLSCREEN', False):
        screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN | pygame.NOFRAME)
    else:
        screen = pygame.display.set_mode((config.SCREEN_WIDTH, config.SCREEN_HEIGHT), pygame.NOFRAME)
    pygame.mouse.set_visible(False)
    pygame.display.set_caption("Ruby Robot Assistant")
    return screen

def destroy_window():
    """Completely destroys the Pygame window, revealing the desktop."""
    if pygame.display.get_init():
        pygame.display.quit()

def main():
    os.makedirs(config.PROJECT_DIR, exist_ok=True)
    os.makedirs(config.PHOTO_DIR, exist_ok=True)
    os.makedirs(config.MUSIC_DIR, exist_ok=True)
    os.makedirs(config.EMBEDDINGS_DIR, exist_ok=True)
    os.chdir(config.PROJECT_DIR)

    # 1. State Primitives & Face Engine
    pygame.init()
    face = RubyFace(screen_width=config.SCREEN_WIDTH, screen_height=config.SCREEN_HEIGHT)
    pygame_stop_event = threading.Event()
    is_speaking_event = threading.Event()
    game_stop_event = threading.Event()
    game_action_queue = queue.Queue()

    # 2. Subsystem Instantiation
    tts = TTSEngine(
        project_dir=config.PROJECT_DIR,
        voice=config.KOKORO_VOICE,
        assistant_name=config.ASSISTANT_NAME,
        face=face,
        is_speaking_event=is_speaking_event
    )
    mover = MovementController(speak_fn=tts.speak)
    music_player = MusicPlayer(speak_fn=tts.speak)
    camera = CameraController(photo_dir=config.PHOTO_DIR, speak_fn=tts.speak, face=face)

    processor = CommandProcessor(
        tts=tts,
        mover=mover,
        music_player=music_player,
        camera=camera,
        game_action_queue=game_action_queue,
        pygame_stop_event=pygame_stop_event
    )

    vosk_phrases = build_vosk_vocabulary()

    listener = VoiceListener(
        model_path=config.VOSK_MODEL_PATH,
        phrases=vosk_phrases,
        command_processor=processor,
        is_speaking_event=is_speaking_event,
        stop_event=pygame_stop_event,
        sample_rate=config.VOSK_SAMPLE_RATE,
        block_seconds=config.MIC_BLOCK_SECONDS
    )
    processor.set_listener(listener)

    # 3. Start Hardware Workers
    camera.init_camera()
    camera.start_stream_worker()
    threading.Thread(target=precache_phrases, args=(tts,), daemon=True).start()
    listener.start()

    clock = pygame.time.Clock()
    screen = None

    # Start with display destroyed if booting in sleep mode
    if not processor.robot_sleeping:
        screen = create_window()
    else:
        destroy_window()

    try:
        while not pygame_stop_event.is_set():
            # 1. Standby State: Window is 100% destroyed, desktop is fully visible
            if processor.robot_sleeping:
                if screen is not None:
                    destroy_window()
                    screen = None
                time.sleep(0.08)
                continue

            # 2. Awake State: Window pops up on the desktop
            if screen is None:
                screen = create_window()

            # Mini-Game Intercept
            if processor.game_active:
                run_maze_game(screen, clock, stop_event=game_stop_event, action_queue=game_action_queue)
                processor.game_active = False
                face.set_mood("NORMAL")
                continue

            for event in pygame.event.get():
                if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
                    pygame_stop_event.set()
                    break

            # 3. Full Camera Preview (Photo Mode)
            cam_surface = camera.get_display_surface(config.SCREEN_WIDTH, config.SCREEN_HEIGHT)
            if cam_surface is not None:
                screen.blit(cam_surface, (0, 0))
            else:
                # 4. Main Robot Face Screen
                face.robot_sleeping = processor.robot_sleeping
                face.current_mode = processor.current_mode
                if is_speaking_event.is_set():
                    face.is_talking = True

                face.update()
                face.draw(screen)

                # 5. Mini Corner HUD (Face Identification / Search)
                if processor.is_scanner_active:
                    draw_corner_scanner(screen, camera, processor.identifier)

            pygame.display.flip()
            clock.tick(30)

    finally:
        logging.info("Shutting down Ruby on Raspberry Pi...")
        pygame_stop_event.set()
        game_stop_event.set()
        music_player.stop()
        mover.release()
        camera.release()
        destroy_window()
        pygame.quit()
        logging.info("Exited cleanly.")

if __name__ == '__main__':
    main()