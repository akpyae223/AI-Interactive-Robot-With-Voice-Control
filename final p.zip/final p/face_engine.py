#!/usr/bin/env python3
import math
import random
import time
import pygame

# Color Palette
BG_COLOR = (12, 14, 20)
EYE_CYAN = (0, 220, 255)
BLUSH_PINK = (255, 105, 145, 160)
TEXT_CYAN = (0, 245, 255)
TEXT_SHADOW = (5, 8, 12)


class RubyFace:
    def __init__(self, screen_width=800, screen_height=480):
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.eye_w = 135
        self.eye_h = 135
        self.spacing = 135
        self.mouth_y_offset = 115

        # Motion & Physics States
        self.offset_x = 0.0
        self.offset_y = 0.0
        self.target_offset_x = 0.0
        self.target_offset_y = 0.0
        self.tilt_angle = 0.0
        self.bounce_y = 0.0
        self.shake_x = 0.0
        self.shake_y = 0.0
        self.squash_stretch = 1.0

        # Mood & Blink State
        self.mood = "SLEEP"
        self.mood_hold_until = 0.0
        self.blink_progress = 1.0
        self.is_blinking = False
        self.blink_start = 0.0
        self.last_blink_time = time.time()
        self.blink_interval = random.uniform(2.5, 4.0)

        # Direction Lock
        self.manual_override = False
        self.lock_look = False
        self.manual_time = 0.0

        # Subtitles & Speaking States
        self.is_talking = False
        self.robot_sleeping = True
        self.current_mode = "idle"
        
        # --- NEW TYPEWRITER / PAGINATION SYSTEM ---
        self.current_subtitle = ""
        self.subtitle_expire_time = 0.0
        self.subtitle_start_time = 0.0
        self.chars_per_second = 24.0  # Speed of typewriter reveal
        self.max_display_lines = 2     # Max lines visible at once
        self.subtitle_font = None

        self.final_x = 0.0
        self.final_y = 0.0

    def init_fonts(self):
        if self.subtitle_font is None:
            pygame.font.init()
            self.subtitle_font = pygame.font.Font(None, 32)

    def set_subtitle(self, text, duration=None, chars_per_sec=24.0):
        self.current_subtitle = str(text).strip()
        self.chars_per_second = chars_per_sec
        self.subtitle_start_time = time.time()
        
        # Auto-calculate duration based on length if not provided
        if duration is None:
            typing_duration = len(self.current_subtitle) / self.chars_per_second
            self.subtitle_expire_time = self.subtitle_start_time + typing_duration + 2.5
        else:
            self.subtitle_expire_time = self.subtitle_start_time + duration

    def clear_subtitle(self):
        self.current_subtitle = ""

    def set_mood(self, new_mood, duration=0.0):
        self.mood = new_mood
        if duration > 0:
            self.mood_hold_until = time.time() + duration
        else:
            self.mood_hold_until = 0.0

    def trigger_bounce(self):
        self.bounce_y = -20.0

    def set_look(self, x, y, lock=False):
        self.manual_override = True
        self.lock_look = lock
        self.manual_time = time.time()
        self.target_offset_x = x
        self.target_offset_y = y

    def reset_look(self):
        self.manual_override = False
        self.lock_look = False
        self.target_offset_x = 0.0
        self.target_offset_y = 0.0

    def update(self):
        now = time.time()

        # Revert temporary mood timers
        if self.mood_hold_until > 0 and now >= self.mood_hold_until:
            self.mood_hold_until = 0.0
            if self.robot_sleeping:
                self.mood = "SLEEP"
            elif self.current_mode != "music":
                self.mood = "NORMAL"

        # 1. Blinking Logic
        if self.mood not in ["HAPPY", "CONFUSED", "SLEEP"]:
            if not self.is_blinking and now - self.last_blink_time > self.blink_interval:
                self.is_blinking = True
                self.blink_start = now
                self.last_blink_time = now
                self.blink_interval = random.uniform(2.2, 4.8)

            if self.is_blinking:
                elapsed = (now - self.blink_start) / 0.15
                if elapsed < 0.5:
                    self.blink_progress = max(0.04, 1.0 - (elapsed * 2))
                elif elapsed < 1.0:
                    self.blink_progress = min(1.0, (elapsed - 0.5) * 2)
                else:
                    self.blink_progress = 1.0
                    self.is_blinking = False
        else:
            self.blink_progress = 1.0

        # 2. Manual Override Timeout
        if not self.lock_look and self.manual_override and (now - self.manual_time > 2.5):
            self.manual_override = False
            self.target_offset_x = 0.0
            self.target_offset_y = 0.0

        self.offset_x += (self.target_offset_x - self.offset_x) * 0.16
        self.offset_y += (self.target_offset_y - self.offset_y) * 0.16

        # 3. Dynamic Motion Physics
        breath = math.sin(now * 3.0) * 4.0
        self.tilt_angle = (self.offset_x / 75.0) * -3.0

        if self.mood == "SLEEP":
            self.bounce_y = math.sin(now * 1.5) * 4.0 + 8.0
            self.squash_stretch = 0.96
            self.shake_x, self.shake_y = 0.0, 0.0
        elif self.mood == "HAPPY" or self.current_mode == "music":
            self.bounce_y = abs(math.sin(now * 9.0)) * -18.0
            self.squash_stretch = 1.0 + math.sin(now * 9.0) * 0.12
            self.shake_x, self.shake_y = 0.0, 0.0
        elif self.mood == "SHY":
            self.bounce_y = math.sin(now * 2.5) * 5.0 + 6.0
            self.squash_stretch = 1.0 + math.sin(now * 2.5) * 0.04
            self.shake_x, self.shake_y = 0.0, 0.0
        elif self.mood == "ANGRY":
            self.shake_x = random.uniform(-2.5, 2.5)
            self.shake_y = 0.0
            self.bounce_y = 0.0
            self.squash_stretch = 0.94
        elif self.mood == "SAD":
            self.bounce_y = math.sin(now * 1.8) * 6.0 + 12.0
            self.shake_x, self.shake_y = 0.0, 0.0
            self.squash_stretch = 0.90
        elif self.mood == "CONFUSED":
            self.tilt_angle = 9.0 + math.sin(now * 2.2) * 2.5
            self.bounce_y = math.sin(now * 2.0) * 4.0
            self.shake_x, self.shake_y = 0.0, 0.0
            self.squash_stretch = 1.0
        else:
            self.shake_x, self.shake_y = 0.0, 0.0
            self.bounce_y += (0.0 - self.bounce_y) * 0.2
            self.squash_stretch += (1.0 - self.squash_stretch) * 0.2

        self.final_x = self.offset_x + self.shake_x
        self.final_y = self.offset_y + breath + self.bounce_y + self.shake_y

    def _draw_z(self, surface, x, y, size, color, alpha=255, stroke=None):
        if stroke is None:
            stroke = max(2, int(size * 0.22))
        z_surf = pygame.Surface((size, size), pygame.SRCALPHA)
        col = (*color[:3], int(alpha))
        pts = [
            (stroke // 2, stroke // 2),
            (size - stroke // 2, stroke // 2),
            (stroke // 2, size - stroke // 2),
            (size - stroke // 2, size - stroke // 2),
        ]
        pygame.draw.lines(z_surf, col, False, pts, stroke)
        surface.blit(z_surf, (x, y))

    def _get_wrapped_lines(self, text, max_width):
        """Helper to break a string into word-wrapped lines."""
        words = text.split(" ")
        lines = []
        current_line = []
        for word in words:
            test_line = " ".join(current_line + [word])
            if self.subtitle_font.size(test_line)[0] <= max_width:
                current_line.append(word)
            else:
                if current_line:
                    lines.append(" ".join(current_line))
                current_line = [word]
        if current_line:
            lines.append(" ".join(current_line))
        return lines

    def draw(self, surface):
        w_scr, h_scr = surface.get_size()
        surface.fill(BG_COLOR)
        now = time.time()
        self.init_fonts()

        face_surf = pygame.Surface((w_scr, h_scr), pygame.SRCALPHA)
        cx = w_scr // 2
        cy = (h_scr // 2) - 40

        # ---------------- EYES GEOMETRY ----------------
        h = max(8, int(self.eye_h * self.blink_progress * self.squash_stretch))
        w = int(self.eye_w * (2.0 - self.squash_stretch))

        lx = cx - self.spacing // 2 - w // 2
        rx = cx + self.spacing // 2 + w // 2

        if self.mood == "SLEEP":
            sleep_w = int(w * 0.9)
            sleep_thickness = 14
            pygame.draw.line(face_surf, EYE_CYAN, (lx - sleep_w // 2, cy), (lx + sleep_w // 2, cy), sleep_thickness)
            pygame.draw.circle(face_surf, EYE_CYAN, (lx - sleep_w // 2, cy), sleep_thickness // 2)
            pygame.draw.circle(face_surf, EYE_CYAN, (lx + sleep_w // 2, cy), sleep_thickness // 2)

            pygame.draw.line(face_surf, EYE_CYAN, (rx - sleep_w // 2, cy), (rx + sleep_w // 2, cy), sleep_thickness)
            pygame.draw.circle(face_surf, EYE_CYAN, (rx - sleep_w // 2, cy), sleep_thickness // 2)
            pygame.draw.circle(face_surf, EYE_CYAN, (rx + sleep_w // 2, cy), sleep_thickness // 2)

            z_configs = [
                {'size': 20, 'base_x': rx + 45, 'base_y': cy - 50, 't_offset': 0.0},
                {'size': 28, 'base_x': rx + 75, 'base_y': cy - 90, 't_offset': 0.8},
                {'size': 38, 'base_x': rx + 115, 'base_y': cy - 135, 't_offset': 1.6},
            ]
            for z in z_configs:
                cycle = ((now * 1.3) + z['t_offset']) % 3.0
                float_progress = cycle / 3.0
                pos_x = int(z['base_x'] + math.sin(cycle * 3.0) * 8.0)
                pos_y = int(z['base_y'] - float_progress * 40.0)
                fade_alpha = max(0, min(255, int(255 * math.sin(float_progress * math.pi))))
                self._draw_z(face_surf, pos_x, pos_y, z['size'], EYE_CYAN, alpha=fade_alpha)

        elif self.mood == "NORMAL":
            radius = min(30, h // 2, w // 2)
            pygame.draw.rect(face_surf, EYE_CYAN, pygame.Rect(lx - w // 2, cy - h // 2, w, h), border_radius=radius)
            pygame.draw.rect(face_surf, EYE_CYAN, pygame.Rect(rx - w // 2, cy - h // 2, w, h), border_radius=radius)

        elif self.mood == "CONFUSED":
            half_r = 54
            pygame.draw.circle(face_surf, EYE_CYAN, (lx, cy), half_r)
            pygame.draw.rect(face_surf, (0, 0, 0, 0), (lx - half_r - 5, cy - half_r - 5, (half_r + 5) * 2, half_r + 5))

            right_r = 58
            pygame.draw.circle(face_surf, EYE_CYAN, (rx, cy - 2), right_r)

            q_x = rx + 30
            q_y = cy - 135 + math.sin(now * 3.5) * 6.0

            arc_rect = pygame.Rect(q_x - 30, q_y - 45, 54, 54)
            pygame.draw.arc(face_surf, EYE_CYAN, arc_rect, math.radians(-50), math.radians(180), 16)

            stalk_pts = [(q_x - 4, q_y - 2), (q_x - 4, q_y + 16)]
            pygame.draw.lines(face_surf, EYE_CYAN, False, stalk_pts, 15)
            pygame.draw.circle(face_surf, EYE_CYAN, (q_x - 4, int(q_y + 36)), 8)

        elif self.mood == "HAPPY" or self.current_mode == "music":
            cw, ch, th = 50, 32, 15
            l_pts = [(lx - cw // 2, cy - ch), (lx + cw // 2, cy), (lx - cw // 2, cy + ch)]
            pygame.draw.lines(face_surf, EYE_CYAN, False, l_pts, th)
            for p in l_pts:
                pygame.draw.circle(face_surf, EYE_CYAN, p, th // 2)

            r_pts = [(rx + cw // 2, cy - ch), (rx - cw // 2, cy), (rx + cw // 2, cy + ch)]
            pygame.draw.lines(face_surf, EYE_CYAN, False, r_pts, th)
            for p in r_pts:
                pygame.draw.circle(face_surf, EYE_CYAN, p, th // 2)

        elif self.mood == "SHY":
            sh_h = int(h * 0.65)
            pygame.draw.rect(face_surf, EYE_CYAN, pygame.Rect(lx - w // 2, cy - sh_h // 2, w, sh_h),
                             border_top_left_radius=sh_h, border_top_right_radius=sh_h,
                             border_bottom_left_radius=4, border_bottom_right_radius=4)
            pygame.draw.rect(face_surf, EYE_CYAN, pygame.Rect(rx - w // 2, cy - sh_h // 2, w, sh_h),
                             border_top_left_radius=sh_h, border_top_right_radius=sh_h,
                             border_bottom_left_radius=4, border_bottom_right_radius=4)

            blush_w, blush_h = 42, 14
            pygame.draw.rect(face_surf, BLUSH_PINK, (lx - w // 2 - 12, cy + sh_h // 2 + 10, blush_w, blush_h), border_radius=7)
            pygame.draw.rect(face_surf, BLUSH_PINK, (rx + w // 2 - blush_w + 12, cy + sh_h // 2 + 10, blush_w, blush_h), border_radius=7)

        elif self.mood == "ANGRY":
            pygame.draw.rect(face_surf, EYE_CYAN, pygame.Rect(lx - w // 2, cy - h // 2, w, h), border_radius=min(w // 2, h // 2))
            pygame.draw.rect(face_surf, EYE_CYAN, pygame.Rect(rx - w // 2, cy - h // 2, w, h), border_radius=min(w // 2, h // 2))
            pygame.draw.polygon(face_surf, (0, 0, 0, 0), [
                (lx - w // 2 - 5, cy - h // 2 - 5),
                (lx + w // 2 + 10, cy - h // 2 + int(h * 0.45)),
                (lx + w // 2 + 10, cy - h // 2 - 10)
            ])
            pygame.draw.polygon(face_surf, (0, 0, 0, 0), [
                (rx - w // 2 - 10, cy - h // 2 + int(h * 0.45)),
                (rx + w // 2 + 5, cy - h // 2 - 5),
                (rx - w // 2 - 10, cy - h // 2 - 10)
            ])

        elif self.mood == "SAD":
            sad_h = int(h * 0.9)
            pygame.draw.rect(face_surf, EYE_CYAN, pygame.Rect(lx - w // 2, cy - sad_h // 2, w, sad_h), border_radius=min(w // 2, sad_h // 2))
            pygame.draw.rect(face_surf, EYE_CYAN, pygame.Rect(rx - w // 2, cy - sad_h // 2, w, sad_h), border_radius=min(w // 2, sad_h // 2))
            pygame.draw.polygon(face_surf, (0, 0, 0, 0), [
                (lx - w // 2 - 10, cy - sad_h // 2 + int(sad_h * 0.45)),
                (lx + w // 2 + 5, cy - sad_h // 2 - 5),
                (lx - w // 2 - 10, cy - sad_h // 2 - 10)
            ])
            pygame.draw.polygon(face_surf, (0, 0, 0, 0), [
                (rx - w // 2 - 5, cy - sad_h // 2 - 5),
                (rx + w // 2 + 10, cy - sad_h // 2 + int(sad_h * 0.45)),
                (rx + w // 2 + 10, cy - sad_h // 2 - 10)
            ])

        # ---------------- MOUTH (LIP-SYNC & REACTIONS) ----------------
        m_x = cx
        m_y = cy + int(self.mouth_y_offset * self.squash_stretch)

        if self.is_talking:
            talk_cycle = abs(math.sin(now * 18.0))
            mw = int(50 + talk_cycle * 25)
            mh = int(14 + talk_cycle * 26)
            pygame.draw.rect(face_surf, EYE_CYAN, pygame.Rect(m_x - mw // 2, m_y - mh // 2, mw, mh), border_radius=mh // 2)

        elif self.mood == "HAPPY" or self.current_mode == "music":
            pygame.draw.rect(face_surf, EYE_CYAN, pygame.Rect(m_x - 47, m_y - 21, 95, 42), border_radius=21)

        elif self.mood == "ANGRY":
            points = [(m_x - 30, m_y + 8), (m_x - 10, m_y - 2), (m_x, m_y + 2), (m_x + 10, m_y - 2), (m_x + 30, m_y + 8)]
            pygame.draw.lines(face_surf, EYE_CYAN, False, points, 6)

        # Apply Face Transformations
        rotated_surf = pygame.transform.rotate(face_surf, self.tilt_angle)
        rot_rect = rotated_surf.get_rect(center=(cx + int(self.final_x), cy + int(self.final_y) + 40))
        surface.blit(rotated_surf, rot_rect)

        # ---------------- PROGRESSIVE SUBTITLES RENDERING ----------------
        show_subtitles = bool(self.current_subtitle) and (now < self.subtitle_expire_time or self.is_talking)
        if show_subtitles:
            # 1. Calculate how many characters to show based on elapsed time
            elapsed = max(0.0, now - self.subtitle_start_time)
            visible_char_count = int(elapsed * self.chars_per_second)
            visible_text = self.current_subtitle[:visible_char_count]

            if visible_text:
                max_line_width = int(w_scr * 0.88)
                lines = self._get_wrapped_lines(visible_text, max_line_width)

                # 2. Window sliding: Keep only the latest N lines
                visible_window = lines[-self.max_display_lines:]

                line_h = 32
                total_text_h = len(visible_window) * line_h
                start_y = h_scr - total_text_h - 24

                for idx, line in enumerate(visible_window):
                    # Shadow
                    shadow_surf = self.subtitle_font.render(line, True, TEXT_SHADOW)
                    shadow_pos = (cx - shadow_surf.get_width() // 2 + 2, start_y + (idx * line_h) + 2)
                    surface.blit(shadow_surf, shadow_pos)

                    # Text
                    txt_surface = self.subtitle_font.render(line, True, TEXT_CYAN)
                    txt_pos = (cx - txt_surface.get_width() // 2, start_y + (idx * line_h))
                    surface.blit(txt_surface, txt_pos)