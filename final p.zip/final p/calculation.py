#!/usr/bin/env python3
import re
import ast
import operator
import logging

NUMBER_WORDS = {
    'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4,
    'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9,
    'ten': 10, 'eleven': 11, 'twelve': 12, 'thirteen': 13, 'fourteen': 14,
    'fifteen': 15, 'sixteen': 16, 'seventeen': 17, 'eighteen': 18, 'nineteen': 19,
    'twenty': 20, 'thirty': 30, 'forty': 40, 'fifty': 50,
    'sixty': 60, 'seventy': 70, 'eighty': 80, 'ninety': 90,
    'hundred': 100, 'thousand': 1000
}

OPERATOR_MAP = {
    'plus': '+',
    'add': '+',
    'added to': '+',
    'minus': '-',
    'subtract': '-',
    'subtracted by': '-',
    'times': '*',
    'multiplied by': '*',
    'multiply': '*',
    'divided by': '/',
    'divide': '/',
    'over': '/',
    'power of': '**',
    'to the power of': '**'
}

SAFE_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
}

class MathEngine:
    def __init__(self):
        pass

    def _words_to_number(self, words):
        total = 0
        current = 0
        for word in words:
            if word in NUMBER_WORDS:
                val = NUMBER_WORDS[word]
                if val in [100, 1000]:
                    current = (current if current != 0 else 1) * val
                else:
                    current += val
            elif word.isdigit():
                current += int(word)
        return total + current

    def parse_spoken_math(self, text):
        clean_text = text.lower().strip()
        prefixes = [
            'what is', 'whats', 'calculate', 'solve', 'can you calculate', 
            'how much is', 'tell me', 'what does', 'equal', 'equals'
        ]
        for p in prefixes:
            clean_text = re.sub(rf'\b{re.escape(p)}\b', '', clean_text)
        
        for word, symbol in sorted(OPERATOR_MAP.items(), key=lambda x: len(x[0]), reverse=True):
            clean_text = re.sub(rf'\b{re.escape(word)}\b', f' {symbol} ', clean_text)

        tokens = clean_text.split()
        if not tokens:
            return None

        math_expr_parts = []
        accumulated_words = []

        for token in tokens:
            if token in ['+', '-', '*', '/', '**']:
                if accumulated_words:
                    num = self._words_to_number(accumulated_words)
                    math_expr_parts.append(str(num))
                    accumulated_words = []
                math_expr_parts.append(token)
            else:
                accumulated_words.append(token)

        if accumulated_words:
            num = self._words_to_number(accumulated_words)
            math_expr_parts.append(str(num))

        expression = " ".join(math_expr_parts).strip()
        if any(op in expression for op in ['+', '-', '*', '/']) and re.search(r'\d', expression):
            return expression
        return None

    def _eval_node(self, node):
        if isinstance(node, ast.Constant):
            return node.value
        elif isinstance(node, ast.BinOp):
            left = self._eval_node(node.left)
            right = self._eval_node(node.right)
            op_type = type(node.op)
            if op_type in SAFE_OPERATORS:
                if op_type == ast.Div and right == 0:
                    raise ZeroDivisionError("Division by zero")
                return SAFE_OPERATORS[op_type](left, right)
        elif isinstance(node, ast.UnaryOp):
            operand = self._eval_node(node.operand)
            op_type = type(node.op)
            if op_type in SAFE_OPERATORS:
                return SAFE_OPERATORS[op_type](operand)
        raise ValueError("Unsupported mathematical expression")

    def calculate(self, text):
        try:
            expr = self.parse_spoken_math(text)
            if not expr:
                return None

            tree = ast.parse(expr, mode='eval')
            result = self._eval_node(tree.body)

            if isinstance(result, float) and result.is_integer():
                result = int(result)
            elif isinstance(result, float):
                result = round(result, 2)

            return f"The answer is {result}."
        except ZeroDivisionError:
            return "I cannot divide by zero."
        except Exception as e:
            logging.debug(f"Math parse skipped: {e}")
            return None
