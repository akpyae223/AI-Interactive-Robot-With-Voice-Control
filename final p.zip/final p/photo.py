#!/usr/bin/env python3
import os
import datetime
import logging
import threading
import time
import cv2
import numpy as np
import pygame

try:
    from picamera2 import Picamera2
    PICAMERA_AVAILABLE = True
except ImportError:
    PICAMERA_AVAILABLE = False
    logging.warning("Picamera2 not installed. Falling back to OpenCV capture.")

class CameraController:
    def __init__(self, photo_dir, speak_fn=None, face=None):
        self.photo_dir = photo_dir
        self.speak = speak_fn if speak_fn else lambda msg: None
        self.face = face
        
        self.picam2 = None
        self.cv_cam = None
        
        self.latest_frame_surf = None       # Pygame preview surface (RGB)
        self.latest_bgr_frame = None        # Raw OpenCV frame for saving (BGR)
        self.captured_frame_bgr = None      # Frozen snapshot BGR
        self.captured_image_surface = None  # Frozen Pygame review surface
        
        self.preview_active = False
        self.is_reviewing = False
        self.is_taking_photo = False
        
        self.cam_lock = threading.Lock()
        self.stop_event = threading.Event()

    def set_callbacks(self, speak_fn=None, face=None):
        if speak_fn:
            self.speak = speak_fn
        if face:
            self.face = face

    def init_camera(self):
        if PICAMERA_AVAILABLE:
            try:
                self.picam2 = Picamera2()
                # Request standard BGR888 to ensure consistent alignment with OpenCV
                config = self.picam2.create_preview_configuration(
                    main={"size": (640, 480), "format": "BGR888"}
                )
                self.picam2.configure(config)
                self.picam2.start()
                logging.info("Picamera2 initialized successfully.")
                return True
            except Exception as e:
                logging.error(f"Picamera2 init error: {e}. Falling back to OpenCV...")
                self.picam2 = None

        try:
            self.cv_cam = cv2.VideoCapture(0, cv2.CAP_V4L2)
            if not self.cv_cam.isOpened():
                self.cv_cam = cv2.VideoCapture(0)
            if self.cv_cam.isOpened():
                self.cv_cam.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                self.cv_cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
                logging.info("OpenCV V4L2 Camera initialized.")
                return True
        except Exception as e:
            logging.error(f"OpenCV Camera fallback error: {e}")
            
        return False

    def is_available(self):
        return (self.picam2 is not None) or (self.cv_cam is not None and self.cv_cam.isOpened())

    def start_stream_worker(self):
        threading.Thread(target=self._stream_worker, daemon=True).start()

    def _stream_worker(self):
        while not self.stop_event.is_set():
            if not self.is_available():
                time.sleep(0.1)
                continue

            frame_bgr = None

            try:
                if self.picam2 is not None:
                    # Raw buffer from libcamera/picam2 is BGR
                    raw_bgr = self.picam2.capture_array()
                    frame_bgr = np.fliplr(raw_bgr)
                elif self.cv_cam is not None:
                    ret, raw_bgr = self.cv_cam.read()
                    if ret and raw_bgr is not None:
                        frame_bgr = cv2.flip(raw_bgr, 1)
            except Exception as e:
                logging.debug(f"Frame capture error: {e}")

            if frame_bgr is not None:
                # Convert BGR to RGB strictly for Pygame surface rendering
                frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
                surf = pygame.surfarray.make_surface(np.rot90(frame_rgb))
                
                with self.cam_lock:
                    self.latest_bgr_frame = frame_bgr  # Retain pure BGR for cv2.imwrite
                    self.latest_frame_surf = surf

            time.sleep(0.03)

    def show_preview(self):
        if self.is_available():
            self.preview_active = True
            self.is_reviewing = False
            self.is_taking_photo = False
            with self.cam_lock:
                self.captured_frame_bgr = None
                self.captured_image_surface = None
            return True
        return False

    def cancel_preview(self):
        self.preview_active = False
        self.is_reviewing = False
        self.is_taking_photo = False
        with self.cam_lock:
            self.captured_frame_bgr = None
            self.captured_image_surface = None

    def _photo_capture_worker(self):
        try:
            self.speak("Three, two, one, smile!")
            time.sleep(0.4)

            with self.cam_lock:
                if self.latest_bgr_frame is not None and self.latest_frame_surf is not None:
                    self.captured_frame_bgr = self.latest_bgr_frame.copy()
                    self.captured_image_surface = self.latest_frame_surf.copy()
                    
                    self.preview_active = False
                    self.is_reviewing = True

                    if self.face:
                        self.face.set_mood("HAPPY", duration=4.0)
                    self.speak("Do you want to save photo or delete it?")
                    return

            self.preview_active = False
            self.is_reviewing = False
            if self.face:
                self.face.set_mood("CONFUSED", duration=3.0)
            self.speak("I had trouble capturing the photo.")
        finally:
            self.is_taking_photo = False

    def take_photo(self):
        if not self.preview_active or self.is_taking_photo or self.is_reviewing:
            return False

        self.is_taking_photo = True
        threading.Thread(target=self._photo_capture_worker, daemon=True).start()
        return True

    def confirm_save(self):
        if not self.is_reviewing:
            return False

        os.makedirs(self.photo_dir, exist_ok=True)
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        filepath = os.path.join(self.photo_dir, f"ruby_photo_{timestamp}.jpg")

        with self.cam_lock:
            if self.captured_frame_bgr is not None:
                # cv2.imwrite accurately writes standard BGR arrays to disk
                cv2.imwrite(filepath, self.captured_frame_bgr)
            self.is_reviewing = False
            self.preview_active = False
            self.is_taking_photo = False
            self.captured_frame_bgr = None
            self.captured_image_surface = None

        if self.face:
            self.face.set_mood("HAPPY", duration=3.0)
            self.face.trigger_bounce()
        self.speak("Photo saved!")
        return True

    def delete_photo(self):
        if not self.is_reviewing:
            return False

        with self.cam_lock:
            self.is_reviewing = False
            self.preview_active = False
            self.is_taking_photo = False
            self.captured_frame_bgr = None
            self.captured_image_surface = None

        if self.face:
            self.face.set_mood("NORMAL", duration=2.5)
        self.speak("Photo deleted.")
        return True

    def get_display_surface(self, screen_width, screen_height):
        if self.is_reviewing and self.captured_image_surface is not None:
            return pygame.transform.scale(self.captured_image_surface, (screen_width, screen_height))
        
        if self.preview_active or self.is_taking_photo:
            with self.cam_lock:
                frame = self.latest_frame_surf
            if frame is not None:
                return pygame.transform.scale(frame, (screen_width, screen_height))
            
            loading_surface = pygame.Surface((screen_width, screen_height))
            loading_surface.fill((20, 24, 35))
            return loading_surface

        return None

    def release(self):
        self.stop_event.set()
        if self.picam2 is not None:
            try:
                self.picam2.stop()
                self.picam2.close()
            except Exception:
                pass
        if self.cv_cam is not None:
            self.cv_cam.release()