#!/usr/bin/env python3
import os
import hashlib
import logging
import threading
import soundfile as sf
import sounddevice as sd

try:
    from kokoro_onnx import Kokoro
except ImportError:
    Kokoro = None

class TTSEngine:
    def __init__(self, project_dir, voice='af', assistant_name='Ruby', face=None, is_speaking_event=None):
        self.project_dir = project_dir
        self.voice = voice
        self.assistant_name = assistant_name
        self.face = face
        self.is_speaking_event = is_speaking_event if is_speaking_event else threading.Event()

        self.cache_dir = os.path.join(self.project_dir, 'kokoro_cache')
        os.makedirs(self.cache_dir, exist_ok=True)

        self.kokoro = None
        self._init_kokoro()

    def _init_kokoro(self):
        if Kokoro is None:
            logging.warning("kokoro_onnx package not installed. Speech will be text-only.")
            return

        model_path = os.path.join(self.project_dir, 'kokoro', 'kokoro-v0_19.onnx')
        voices_path = os.path.join(self.project_dir, 'kokoro', 'voices.bin')

        if not os.path.isfile(model_path):
            fallback_model = os.path.expanduser('~/AIRobot/kokoro/kokoro-v0_19.onnx')
            if os.path.isfile(fallback_model):
                model_path = fallback_model

        if not os.path.isfile(voices_path):
            fallback_voices = os.path.expanduser('~/AIRobot/kokoro/voices.bin')
            if os.path.isfile(fallback_voices):
                voices_path = fallback_voices
            else:
                json_alt = os.path.join(self.project_dir, 'kokoro', 'voices.json')
                if os.path.isfile(json_alt):
                    voices_path = json_alt

        if os.path.isfile(model_path) and os.path.isfile(voices_path):
            try:
                self.kokoro = Kokoro(model_path, voices_path)
                logging.info("Kokoro Neural TTS loaded successfully.")
            except Exception as e:
                logging.error(f"Failed to load Kokoro TTS: {e}")
        else:
            logging.warning("Kokoro model or voices.bin not found. Speech output will be muted.")

    def _get_cache_path(self, text):
        clean_text = text.strip()
        h = hashlib.md5(f"{self.voice}_{clean_text}".encode('utf-8')).hexdigest()
        return os.path.join(self.cache_dir, f"{h}.wav")

    def precache_phrases(self, phrases):
        if not self.kokoro:
            return

        for phrase in phrases:
            if not phrase:
                continue
            cache_file = self._get_cache_path(phrase)
            if not os.path.isfile(cache_file):
                try:
                    samples, sample_rate = self.kokoro.create(phrase, voice=self.voice, speed=1.0, lang="en-us")
                    sf.write(cache_file, samples, sample_rate)
                except Exception as e:
                    logging.debug(f"Precache failed for '{phrase}': {e}")

    def speak(self, text):
        if not text:
            return

        clean_text = text.strip()
        print(f"\n{self.assistant_name}: {clean_text}")

        # 1. Forward spoken text to RubyFace for dynamic on-screen subtitles
        if self.face and hasattr(self.face, 'set_subtitle'):
            # Calculate subtitle display time based on sentence length
            duration = max(3.0, len(clean_text) * 0.08 + 1.2)
            self.face.set_subtitle(clean_text, duration=duration)

        cache_file = self._get_cache_path(clean_text)
        samples = None
        sample_rate = 24000

        # 2. Load pre-cached WAV or synthesize with Kokoro
        if os.path.isfile(cache_file):
            try:
                samples, sample_rate = sf.read(cache_file, dtype='float32')
            except Exception as e:
                logging.error(f"Error reading audio cache: {e}")

        if samples is None and self.kokoro is not None:
            try:
                samples, sample_rate = self.kokoro.create(clean_text, voice=self.voice, speed=1.0, lang="en-us")
                try:
                    sf.write(cache_file, samples, sample_rate)
                except Exception:
                    pass
            except Exception as e:
                logging.error(f"Kokoro live synthesis error: {e}")
                return

        if samples is None:
            return

        # 3. Synchronize speaking state for lip-sync & mic silencing
        self.is_speaking_event.set()
        if self.face:
            self.face.is_talking = True

        try:
            # latency='high' prevents audio crackling and underruns on Raspberry Pi
            sd.play(samples, samplerate=sample_rate, latency='high')
            sd.wait()
        except Exception as e:
            logging.error(f"Audio playback error: {e}")
        finally:
            self.is_speaking_event.clear()
            if self.face:
                self.face.is_talking = False